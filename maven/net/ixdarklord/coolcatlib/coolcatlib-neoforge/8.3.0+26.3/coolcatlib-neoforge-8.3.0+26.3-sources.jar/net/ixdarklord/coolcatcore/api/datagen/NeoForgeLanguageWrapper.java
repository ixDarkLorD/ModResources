package net.ixdarklord.coolcatcore.api.datagen;

import net.ixdarklord.coolcatcore.api.datagen.language.AbstractLanguageWrapper;
import net.ixdarklord.coolcatcore.api.datagen.language.LanguageProvider;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import org.jetbrains.annotations.NotNull;

import java.util.function.Supplier;

/**
 * Forge adapter that wraps {@link LanguageProvider}.
 */
public class NeoForgeLanguageWrapper extends net.neoforged.neoforge.common.data.LanguageProvider {

    private final AbstractLanguageWrapper wrapper;
    private final String modid;

    /**
     * Creates a new Forge language wrapper for {@code en_us}.
     *
     * @param output   The data output.
     * @param modid    The mod ID.
     * @param provider The internal language provider.
     */
    public NeoForgeLanguageWrapper(PackOutput output, String modid, LanguageProvider provider) {
        this(output, modid, "en_us", provider);
    }

    /**
     * Creates a new Forge language wrapper for a specific locale.
     *
     * @param output   The data output.
     * @param modid    The mod ID.
     * @param locale   The locale (e.g. "en_us", "es_es").
     * @param provider The internal language provider.
     */
    public NeoForgeLanguageWrapper(PackOutput output, String modid, String locale, LanguageProvider provider) {
        super(output, modid, locale);
        this.modid = modid;
        this.wrapper = new AbstractLanguageWrapper(provider);
    }

    @Override
    protected void addTranslations() {
        wrapper.generateTranslations(this::add);
    }

    @Override
    public @NotNull String getName() {
        return String.format("%s %s", this.modid, super.getName());
    }

    /**
     * Creates a factory for generating language data providers targeting the
     * default locale ({@code en_us}).
     * <p>
     * This method is a convenience for the common case where only English
     * localization data is generated. It can be directly passed to Forge's
     * {@code DataGenerator#addProvider} method.
     * <p><strong>Example usage:</strong>
     * <pre>{@code
     * generator.addProvider(true,
     *     ForgeLanguageWrapper.factory("coolcatmod", MyEnglishLanguageProvider::new));
     * }</pre>
     *
     * @param modid    The mod ID used to locate the generated language file.
     * @param supplier A supplier that creates the wrapped {@link LanguageProvider}.
     * @return A {@link DataProvider.Factory} instance producing {@link NeoForgeLanguageWrapper} objects for {@code en_us}.
     */
    public static DataProvider.Factory<NeoForgeLanguageWrapper> factory(String modid, Supplier<LanguageProvider> supplier) {
        return factory(modid, "en_us", supplier);
    }

    /**
     * Creates a factory for generating language data providers targeting a specific locale.
     * <p>
     * This method allows multiple translations to be generated (for example,
     * {@code en_us}, {@code es_es}, {@code de_de}) by providing a distinct
     * {@link LanguageProvider} implementation for each locale.
     * <p><strong>Example usage:</strong>
     * <pre>{@code
     * generator.addProvider(true,
     *     ForgeLanguageWrapper.factory("coolcatmod", "es_es", MySpanishLanguageProvider::new));
     * }</pre>
     *
     * @param modid    The mod ID used to locate the generated language file.
     * @param locale   The locale code (e.g. {@code en_us}, {@code es_es}, {@code fr_fr}).
     * @param supplier A supplier that creates the wrapped {@link LanguageProvider}.
     * @return A {@link DataProvider.Factory} instance producing {@link NeoForgeLanguageWrapper} objects for the specified locale.
     */
    public static DataProvider.Factory<NeoForgeLanguageWrapper> factory(String modid, String locale, Supplier<LanguageProvider> supplier) {
        return output -> new NeoForgeLanguageWrapper(output, modid, locale, supplier.get());
    }
}
