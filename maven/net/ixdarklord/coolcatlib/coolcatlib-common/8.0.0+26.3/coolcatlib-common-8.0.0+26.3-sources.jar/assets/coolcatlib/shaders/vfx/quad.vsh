#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:projection.glsl>
#include <coolcatlib:vfx.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;

layout(location = 0) out vec2 texCoord;
layout(location = 1) out vec4 vertexColor;

void main() {
    gl_Position = ProjMat * VfxViewMat * vec4(Position, 1.0);
    texCoord = UV0;
    vertexColor = Color;
}
