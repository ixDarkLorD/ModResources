package net.ixdarklord.coolcatcore.internal.event.fabric;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.Event;
import net.ixdarklord.coolcatcore.api.event.v2.client.ClientCommandEvents;
import net.ixdarklord.coolcatcore.api.event.v2.client.ClientGuiEvents;
import net.ixdarklord.coolcatcore.api.event.v2.client.ClientPlayerEvents;
import net.ixdarklord.coolcatcore.api.event.v2.client.ItemTooltipEvents;
import net.ixdarklord.coolcatcore.api.event.v2.core.EventPhase;
import net.ixdarklord.coolcatcore.internal.core.CoolCatCore;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.resources.ResourceLocation;

// Fires CoolCatLib's client events from Fabric's.
public final class FabricClientEventHooks {
    private FabricClientEventHooks() {}

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void register() {
        ClientTickEvents.START_CLIENT_TICK.register(minecraft ->
                net.ixdarklord.coolcatcore.api.event.v2.client.ClientTickEvents.START.invoker().onStartTick(minecraft));
        ClientTickEvents.END_CLIENT_TICK.register(minecraft ->
                net.ixdarklord.coolcatcore.api.event.v2.client.ClientTickEvents.END.invoker().onEndTick(minecraft));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, minecraft) -> {
            if (minecraft.player != null) ClientPlayerEvents.JOIN.invoker().onJoin(minecraft.player);
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, minecraft) -> ClientPlayerEvents.LEAVE.invoker().onLeave(minecraft.player));

        // Drawn after vanilla's HUD.
        HudRenderCallback.EVENT.register((graphics, partialTick) -> {
            if (ClientGuiEvents.RENDER_HUD.hasListeners()) ClientGuiEvents.RENDER_HUD.invoker().render(graphics, partialTick);
        });

        // Each band in its own Fabric phase: FIRST before other mods' tooltip callbacks (the default phase), LAST after.
        ResourceLocation firstPhase = CoolCatCore.rl("first");
        ResourceLocation lastPhase = CoolCatCore.rl("last");
        ItemTooltipCallback.EVENT.addPhaseOrdering(firstPhase, Event.DEFAULT_PHASE);
        ItemTooltipCallback.EVENT.addPhaseOrdering(Event.DEFAULT_PHASE, lastPhase);
        ItemTooltipCallback.EVENT.register(firstPhase, (stack, flag, lines) -> {
            if (ItemTooltipEvents.MODIFY.hasListeners(EventPhase.Band.FIRST)) ItemTooltipEvents.MODIFY.invoker(EventPhase.Band.FIRST).modify(stack, flag, lines);
        });
        ItemTooltipCallback.EVENT.register((stack, flag, lines) -> {
            if (ItemTooltipEvents.MODIFY.hasListeners(EventPhase.Band.MIDDLE)) ItemTooltipEvents.MODIFY.invoker(EventPhase.Band.MIDDLE).modify(stack, flag, lines);
        });
        ItemTooltipCallback.EVENT.register(lastPhase, (stack, flag, lines) -> {
            if (ItemTooltipEvents.MODIFY.hasListeners(EventPhase.Band.LAST)) ItemTooltipEvents.MODIFY.invoker(EventPhase.Band.LAST).modify(stack, flag, lines);
        });

        // FabricClientCommandSource is a SharedSuggestionProvider, the source type client commands are built with.
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, context) ->
                ClientCommandEvents.REGISTER.invoker().register((CommandDispatcher<SharedSuggestionProvider>) (CommandDispatcher) dispatcher, context));
    }
}
