package net.ixdarklord.coolcatcore.api.event.v2.client;

import com.mojang.brigadier.CommandDispatcher;
import net.ixdarklord.coolcatcore.api.command.ModCommands;
import net.ixdarklord.coolcatcore.api.event.v2.core.EventInvoker;
import net.ixdarklord.coolcatcore.internal.config.CommandOwners;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;

/**
 * Client-side commands. The loaders use different command sources (Fabric's {@code FabricClientCommandSource},
 * NeoForge's {@code CommandSourceStack}); both are {@link SharedSuggestionProvider}s, which is the type commands are
 * built with here. Reply through {@link #sendFeedback} / {@link #sendError}.
 */
public final class ClientCommandEvents {
    /**
     * The client's commands are being made: on joining a world or server.
     *
     * @deprecated Use {@link ModCommands#registerClient}, which takes the mod's id and its command's names (and
     * aliases). Listeners here still work.
     */
    @Deprecated
    public static final EventInvoker<Register> REGISTER = EventInvoker.create(Register.class, listeners -> (dispatcher, context) -> {
        CommandOwners.registerDeclaredClient(dispatcher, context);
        for (Register listener : listeners) listener.register(dispatcher, context);
    });

    private ClientCommandEvents() {}

    /** A message in the chat, as a command's reply. */
    public static void sendFeedback(Component message) {
        Minecraft.getInstance().gui.hud.getChat().addClientSystemMessage(message);
    }

    /** An error reply, in red. */
    public static void sendError(Component message) {
        sendFeedback(message.copy().withStyle(ChatFormatting.RED));
    }

    /** @deprecated Use {@link ModCommands.ClientBuilder}, through {@link ModCommands#registerClient}. */
    @Deprecated
    @FunctionalInterface
    public interface Register {
        void register(CommandDispatcher<SharedSuggestionProvider> dispatcher, CommandBuildContext context);
    }
}
