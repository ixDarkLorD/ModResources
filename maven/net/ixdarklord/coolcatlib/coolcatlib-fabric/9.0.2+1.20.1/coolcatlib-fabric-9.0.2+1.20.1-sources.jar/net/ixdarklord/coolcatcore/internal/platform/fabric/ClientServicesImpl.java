package net.ixdarklord.coolcatcore.internal.platform.fabric;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;
import net.ixdarklord.coolcatcore.api.client.registry.MenuScreenRegistry;
import net.ixdarklord.coolcatcore.api.network.CustomPacketPayload;
import net.ixdarklord.coolcatcore.internal.platform.ClientServices;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.MenuAccess;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;
import java.util.function.Supplier;

public final class ClientServicesImpl implements ClientServices {
    private static final ClientServices INSTANCE = new ClientServicesImpl();

    public static ClientServices get() {
        return INSTANCE;
    }

    @Override
    public void registerKeyMapping(KeyMapping mapping) {
        KeyBindingHelper.registerKeyBinding(mapping);
    }

    // Menu types are registered by now on Fabric (the main entrypoint runs first), so the screen goes in straight away.
    @Override
    public <M extends AbstractContainerMenu, U extends Screen & MenuAccess<M>> void registerMenuScreen(Supplier<? extends MenuType<? extends M>> type, MenuScreenRegistry.ScreenFactory<M, U> factory) {
        MenuScreens.<M, U>register(type.get(), factory::create);
    }

    @Override
    public <T extends TooltipComponent> void registerTooltipComponent(Class<T> type, Function<? super T, ? extends ClientTooltipComponent> factory) {
        TooltipComponentCallback.EVENT.register(data -> type.isInstance(data) ? factory.apply(type.cast(data)) : null);
    }

    @Override
    public <T extends BlockEntity> void registerBlockEntityRenderer(Supplier<? extends BlockEntityType<? extends T>> type, BlockEntityRendererProvider<T> provider) {
        BlockEntityRendererRegistry.register(type.get(), provider);
    }

    @Override
    public <T extends Entity> void registerEntityRenderer(Supplier<? extends EntityType<? extends T>> type, EntityRendererProvider<T> provider) {
        EntityRendererRegistry.register(type.get(), provider);
    }

    @Override
    public void registerBlockRenderLayer(Supplier<? extends Block> block, RenderType layer) {
        BlockRenderLayerMap.INSTANCE.putBlock(block.get(), layer);
    }

    // One layer a block, as Fabric's chunks build it (with Indigo or another renderer behind the model renderer).
    @Override
    public void tesselateWorldBlock(BlockAndTintGetter level, BlockState state, BlockPos pos, PoseStack pose, Function<RenderType, VertexConsumer> buffers, RandomSource random) {
        BlockRenderDispatcher blocks = Minecraft.getInstance().getBlockRenderer();
        pose.pushPose();
        blocks.getModelRenderer().tesselateBlock(level, blocks.getBlockModel(state), state, pos, pose, buffers.apply(ItemBlockRenderTypes.getChunkRenderType(state)),
                true, random, state.getSeed(pos), OverlayTexture.NO_OVERLAY);
        pose.popPose();
    }

    @Override
    public void sendToServer(CustomPacketPayload payload) {
        FabricClientNetworking.send(payload);
    }
    // Extra models go in through Fabric's model loading plugin, registered once, which asks the providers at every load.
    private static final List<Function<ResourceManager, Collection<ResourceLocation>>> EXTRA_MODELS = new CopyOnWriteArrayList<>();
    private static boolean modelPluginRegistered;

    @Override
    public synchronized void registerExtraModels(Function<ResourceManager, Collection<ResourceLocation>> provider) {
        EXTRA_MODELS.add(provider);
        if (!modelPluginRegistered) {
            modelPluginRegistered = true;
            ModelLoadingPlugin.register(context -> {
                // The packs being loaded are the game's by now: a reload puts them in place before its listeners run.
                ResourceManager resources = Minecraft.getInstance().getResourceManager();
                EXTRA_MODELS.forEach(source -> context.addModels(source.apply(resources)));
            });
        }
    }

    @Override
    public BakedModel getExtraModel(ResourceLocation model) {
        return Minecraft.getInstance().getModelManager().getModel(model);
    }
}
