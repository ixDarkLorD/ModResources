# Changelog
This file is for listing all the changes to this project

## v8.2.2 Release | Nov 13, 2026
### 🐛 Bug Fixes
- Fixed a memory leak on Forge: CoolCatLib kept every block entity the game had made (all but vanilla containers) for the whole session, so memory filled up over long sessions or with machines that make and remove many block entities.

## v8.2.1 Release | Nov 12, 2026
### 🐛 Bug Fixes
- No longer crashes the game alongside Citadel (or any mod that changes the smithing table's recipe lookup): CoolCatLib's hooks added in 8.2.0 (the smithing table's recipes, a merchant's offers, and BlockViews' chunk data) now wrap the game's calls instead of replacing them, so other mods can change the same calls too.

## v8.2.0 Release | Nov 10, 2026
### ✨ New Features
- More common events (`api.event.v2.common`), fired the same on every loader:
  - `EntityEvents.SPAWN`: a new mob is about to be added to the world (spawned naturally or with a new chunk, by a spawner, a spawn egg, a command, breeding, a conversion), with why it was made when the game says; interrupt to keep it out, with its passengers. `EntityEvents.MOUNT`: an entity is about to ride another (interrupt to keep it off), or got off one.
  - `PlayerEvents.OPEN_MENU`: a player is about to open a menu: a block's, an entity's, an item's, or one another mod opens with extra data; interrupt to keep it closed.
  - `RecipeEvents.MATCH`: a recipe matched where the game looks one up (furnaces, campfires, smithing tables, stonecutters, crafting grids, other mods' machines), with the block entity or the player asking; interrupt to pass it over for the next one that matches.
  - `PlayerEvents.ADVANCEMENT_EARNED` (a player completed an advancement), `CommandEvents.EXECUTE` (a command is about to run; interrupt to stop it) and `LivingEvents.EFFECT_APPLICABLE` (an effect is about to be given; interrupt to keep it off).
  - `BlockEvents.DROPS`: a broken block is about to drop its items and experience; change the list and the amount.
  - `PlayerEvents.BREAK_SPEED` and `HARVEST_CHECK`: how fast a player breaks a block, and whether their tool is right for it (without it, it drops nothing), on both sides.
  - `MerchantEvents.OFFERS`: the trades a player is shown, as their own list; take trades out to hide them (they can't make them either).
  - `EnchantEvents.TABLE_OPTIONS` (the enchantments an enchanting table's offer gives) and `ANVIL_RESULT` (what an anvil makes; interrupt with another stack or none).
  - `LootEvents.MODIFY`: any loot table's loot as it's rolled (chests, block drops, mobs, fishing), with the table's id; change the list.
  - `LivingEvents.DAMAGE` (before armor; interrupt and no damage is taken) and `DEATH` (interrupt to keep the entity alive), as on 26.1.2.
- Blocks that look like other blocks to some players (`api.block.BlockViews`): `BlockViews.register(id, view)` adds a `BlockView`, which groups players by a key (players with the same key see the same, and a null key leaves everything as it is for them) and says what a block looks like to them. What the server sends them (chunks, block changes, block entities' data) has that block in its place, so their client never knows the real one, while the server keeps it for everything else. `BlockViews.refresh(player)` sends them their chunks again when what they should see changes.
- `BlockEntityRendererRegistry` (`api.client.registry`): registers block entity renderers, the same on every loader, as on 26.x.
- `BlockRenderLayers` (`api.client.registry`): `register(block, RenderType.translucent())` (or `cutout()`, `cutoutMipped()`) draws a block's model in that layer, for textures with clear or partly see-through pixels, the same on every loader.

## v8.1.0 Release | Nov 3, 2026
### 🔧 Changes
- CoolCatLib's own config screen (used without Glazed Menu) lists each config as a row, instead of a card with artwork: its kind's icon, its name over what its kind means, and how many settings it has. A mod's own card artwork at `assets/<modid>/textures/gui/config/cards/<config name>.png` is no longer used.
- Each kind of config has its own color in the config list (client blue, common teal, server purple, startup orange, world green), unless the config sets its own theme; its rows are centered in the list and as tall as needed to fit without scrolling.
- The list of every mod's configs has a new icon (a puzzle piece with a gear), drawn in the theme's accent, and the header's icons no longer sit in a box.
- Config screens are in CoolCatLib's logo colors by default (warm brown, cream and orange, in dark and light mode), for mods that don't set their own: `ConfigColorScheme.COOLCATLIB` and `COOLCATLIB_LIGHT`, used by `ConfigTheme.DEFAULT` and any theme built without colors.

### 🐛 Bug Fixes
- Opening CoolCatLib's config screens no longer crashes the game over a large mod icon (on 1.20.1, CoolCatLib's own logo was enough); an icon that can't be loaded is left out, with a warning in the log.
- Mod icons larger than 512 pixels are scaled down before they're uploaded, as nothing is drawn near that size.
- CoolCatLib's config list says when no mod has a config there, instead of showing an empty panel.

## v8.0.1 Release | Nov 2, 2026
### 🐛 Bug Fixes
- `ItemTooltipEvents.APPEND`'s lines go above the game's advanced tooltip lines (durability, the item's id, its NBT tag count) rather than under them.

## v8.0.0 Release | Oct 26, 2026
### ✨ New Features
- More common events (`api.event.v2.common`), fired the same on Fabric and Forge:
  - `BlockEvents.PLACE`: a block is about to be placed, by any block item (players, dispensers, other mods' machines) or an enderman; interrupt and it isn't, and the item isn't used up.
  - `PlayerEvents.PICKUP_ITEM` (interrupt to leave the item on the ground), `TRAVEL_TO_DIMENSION` (before any teleport to another dimension: portals, commands, other mods' teleporters; interrupt to stay), `CRAFTED` and `SMELTED` (an item taken from a crafting or furnace result slot).
  - `PlayerEvents.CLONE` (the new player object after death or the End, to carry data over), `RESPAWN` and `CHANGE_DIMENSION`.
  - `LivingEvents.EQUIPMENT_CHANGE`: what an entity wears or holds in a slot changed.
  - `RecipeEvents.CRAFT_RESULT`: a crafting recipe's result for a crafting grid; interrupt with another stack, or an empty one so nothing can be crafted. On this version it gets the game's `Recipe` and `CraftingContainer` (there is no crafter block).
- Game tests from common code (`api.gametest`), as on 26.1.2 and the same on Fabric and Forge: `GameTests.register(modId, SomeTests.class)` registers every `@GameTest` method (as `<modid>:<class>/<method>`), and `GameTests.register(id, options, helper -> ...)` one test by hand. `GameTestOptions` sets the structure, time limit, setup ticks, rotation, retries and batch (one per mod by default; there are no test environments on this version); without a structure of their own, tests run on CoolCatLib's `coolcatlib:gametest/platform`, an empty 8 × 6 × 8 space on a stone floor. Positions count from the structure's corner, as on newer versions. Tests are added in a development environment or with `-Dcoolcatlib.gametest=true` (or the loader's own game test switch), then run with `/test run <modid>.<class>.<method>`, `/test runall <modid>` or on a game test server.
- Attachments on levels and on the server: `get`, `set`, `update`, `modify`, `has` and `reset` take a `Level` or the `MinecraftServer`, saved in the level's data folder (the server's in the overworld's) and synced (`SyncPolicy.ALL`) to the players in the level, or to everyone. `getGlobal(level)` reads the server's values on either side.
- Offline players' attachments: `getOffline`, `setOffline`, `updateOffline` and `resetOffline` read and write a player's saved values whether or not they're online (an offline player's data file is written at once).

- Sound filters (`api.client.sound`): muffle, roughen and echo the game's sounds, as heard through a wall, under a spell or in a cave.
  - A `SoundFilter` is how loud a sound stays, how much of its high end it keeps, and how much of it goes through a distortion and into a reverb. `muffled`, `quieter`, `distorted` and `echoing` make the usual ones; `then` combines two and `lerp` goes part of the way, for fades.
  - `SoundFilters.register(provider)` adds a `SoundFilterProvider`, asked about each sound as it starts and as it moves, with a `SoundContext`: where it plays, which sound event it is, its category and whether it is relative to the listener (music, the menus; the menus' clicks are relative MASTER sounds here, as this version has no UI category). `SoundFilterProvider.inWorld` makes one for the sounds in the world only, by their place. `register` gives back a `Registration` to `remove()` it again.
  - Named filters for every sound at once (but the menus' clicks): `SoundFilters.set(id, filter, fadeTicks)` fades one in, `clear(id, fadeTicks)` out again; `isSet(id)`. From the server, `SoundFilterControl.set` and `clear` (`api.sound`) do the same for a player.
  - `SoundFilters.refresh()` filters the sounds already playing again, when a provider's answers change.
  - Through OpenAL's EFX extension (a low-pass filter on each sound, sent to a distortion and a reverb effect); without it, sounds are left as they are.
- Items drawn in a GUI at an opacity (`api.client.gui.ItemOpacityRenderer`), flat and solid ones alike, where the game draws them only fully opaque: `render` and `renderWithDecorations` (with the count and durability bar) at an opacity or an `OpacityTween` (`in`, `out`, `between`, eased over ticks and smooth at any frame rate), and `withOpacity(opacity, draw)` for anything that draws items, fading the text and bars drawn with them too. Any item drawn while the shader color's alpha is under 1 fades with it, the game's own included.
- Placing GUI elements out of the way of everything else (`api.client.gui.placement`): `GuiAreas.hud()` and `screen()` give the boxes of what the HUD (every mod's HUD layers too: minimaps, block tooltips, boss bars) and the open screen drew last frame, the screen's widgets included but not its background or the tooltip under the mouse; `GuiAreas.unrecorded(draw)` draws your own element without it counting. `GuiPlacement.hud()` / `screen()` take a size, where you'd like it (`at`), a `gap`, the bounds to stay `within` and the `directions` it may slide in, leave out overlays and whatever you `ignore`, and `find()` the nearest clear place.
- World effect layers: `frame.draw(material, VfxLayer.of(n))` draws in a layer, lowest first, so a higher layer always covers a lower one. A `VfxLayer.sorted(n)` layer draws its painted-over shapes of every material back to front, so shapes of different textures cover each other as their distance says. Materials in a layer now draw in the order they were first used each frame, where before they drew in no set order.

### 🔧 Changes
- Config screens call configs by their own name ("Client", "Server"), after their mod's name where it matters ("Testing Mod › Client"), instead of a title made from the mod id ("Testingmod Client"): in a config's screen, its category popups, the config cards' tooltips and search results, and saved notices. Translate a config's name with `config.<modid>.<name>.label`.
- New version numbers: `<version>+<minecraft>`, this one `8.0.0+1.20.1`, the same for every Minecraft version and loader. They follow on from 2001.4.0.1; the part before the `+` is what launchers and loaders compare, the Minecraft version after it is only a label. Depending on CoolCatLib: ask for `>=8.0.0`, and the Maven artifacts are `coolcatlib-<loader>:8.0.0+1.20.1`.

## v2001.4.0.1 Release | Oct 22, 2026
### 🐛 Bug Fixes
- Screen effects, skyboxes, world effects and ghost blocks no longer leave the game believing its own shader is still bound. Vanilla skips binding a core or post shader it bound last; after one of CoolCatLib's programs, the next draw with that shader could run with the wrong program (or none) and send its uniforms to it.

### 🔧 Changes
- CoolCatLib's shader programs remember their uniform locations and the values last sent, so a uniform set to the value it already has (samplers, unchanged matrices, every frame) costs no GL call, and matrices are sent without a temporary buffer.

## v2001.4.0.0 Release | Oct 22, 2026
### ✨ New Features
- World effects (`api.client.vfx`), as on 26.1.2: glowing shapes drawn in the world, after the whole level and before the hand, lit by nothing. They hide behind solid things and fade softly where they meet them (`VfxMaterial.softness`), so nothing ends in a hard line at a wall or the ground.
  - Materials (`VfxMaterial`): a texture, a blend (`VfxBlend.ADDITIVE` for light, `ALPHA` for smoke, `LUMINOUS` for black-background glow textures against bright skies), a softness, and smooth or pixel-for-pixel sampling (`withSmoothing(false)` keeps block and item textures crisp). Everything of one material in a frame is one draw call.
  - Effect particles (`ParticleSpec`, `WorldParticles`): size, opacity and spin follow three-point eased curves (`Curve`, now with `Curve.FADE`) over each particle's life, colour shifts around the colour wheel, lifetimes are randomised, with gravity, drag and velocity-stretched sparks (`Shape.SPARK`). `WorldParticles.spawn`, `burst` and `line`. They are not vanilla particles: nothing to register, nothing on the server.
  - Shapes every frame (`WorldVfx.register` with a `VfxRenderer`, drawing through `VfxFrame` and `VfxDraw`): camera-facing billboards, beams, flat ground quads, free quads, and ribbons that follow a `Trail`. One-liners that draw themselves and fade: `WorldVfx.beam`, `flash` and `groundFlash`.
  - Built-in textures: `VfxMaterial.GLOW`, `SPARKLE`, `STAR`, `RING`, `SMOKE` and `STREAK`.
  - Shader materials: `VfxMaterial.withShader(id)` draws a material with a fragment shader of the mod's own (`assets/<namespace>/shaders/<path>.fsh`, GLSL 150 on this version), which imports `coolcatcanvas:vfx.glsl` for the camera, the time and the depth-fade helpers.
  - Rifts (`WorldRifts`, `RiftSpec`, `Rift`): a tear in the air drawn by a built-in shader (`VfxMaterial.RIFT_SHADER`) that opens with a flash, a sound and a shake, hums while open, and snaps shut; `rift.facing(direction)` holds it facing one way, as a portal in a wall.
  - From the server (`api.vfx`): `VfxControl.play(level, id, VfxParams)` plays an effect a client registered with `VfxEffects.register`, and `RiftControl.open(level, spec id, position[, ticks])` and `close(level, id)` open and close rifts, each as one small packet to the players in range.
- Event phases reach other mods' own listeners: `EventPhase.band()` sorts phases into `FIRST` (FIRST and earlier), `MIDDLE` and `LAST` (LAST and later), and events whose loader hook fires each band at its own place run `FIRST` listeners before other mods' Forge or Fabric listeners of the game event and `LAST` ones after them. `EventInvoker.invoker(Band)` and `hasListeners(Band)` let a hook fire one band; `invoker()` still fires them all, in order.
- `ItemTooltipEvents.MODIFY` does this on every loader (Forge's highest, normal and lowest priorities; Fabric phases before, at and after the default one).
- `ItemTooltipEvents.APPEND`: lines added at the very end of an item's tooltip, after the loaders' tooltip events and every other mod's lines, with the player when there is one.
- `InteractionEvents` (`api.event.v2.common`): `USE_BLOCK`, `USE_ITEM` and `USE_ENTITY` (answer with an `InteractionResult`: `PASS` lets the game go on, anything else stops it there) and `ATTACK_BLOCK` and `ATTACK_ENTITY` (interrupt to stop them), on both sides, before the game acts, the same on Fabric and Forge.
- `HeldItemSwaps` (`api.client.item`): which changes to a held stack are quiet, so the item stays where it is in the hand instead of being put away and taken out again: `quiet(...)` for keys of the stack's NBT, `register(...)` for any test of the old and new stacks. Attachments' changes are quiet unless the attachment was built with `swapAnimation()`.
- `GhostBlocks` (`api.client.vfx`): blocks drawn as ghosts with their real models (block entities too), one see-through picture so only their outside shows, tinted and faded by one colour; shown through walls, in the world as real blocks would be, or always; full bright or shaded. Call it right after the level is drawn.
- Scene viewports (`api.client.viewport.SceneViewport`, `api.client.gui.components.SceneViewportWidget`): a 3D view of blocks, block entities, entities and items, drawn into a texture of its own (by the game's own renderers, lit as the world is) for a GUI or any textured face; turned, zoomed and framed in code or by dragging, with a ground of grid lines and shadows, and text laid flat on the picture.
- `ItemRendererRegistry` (`api.client.registry`): items drawn in code, the same on every loader: an item whose model is `builtin/entity` is drawn by its renderer wherever it shows.
- `ItemColorRegistry` (`api.client.registry`): colours for items' tinted faces, the same on every loader.
- `ExtraModels` (`api.client.registry`): models baked with the game's though no item or block uses them, for drawing in code; named outright or found in the resources as they load.

## v2001.3.0.0 Release | Oct 14, 2026
### 🔧 Changes
- CoolCatLib is one mod again: **CoolCatLib: Core** and **CoolCatLib: Canvas** are merged into **CoolCatLib**, one jar per loader. Screen effects, skyboxes, GUI widgets and the render utilities now ship with the events, networking, registries and configs, so there is one file to install and one version to depend on.
- The mod id is now `coolcatlib`. With it changed: the Fabric entrypoints (`coolcatlib:common`, `coolcatlib:client`, `coolcatlib:server`, `coolcatlib:datagen`), the commands (`/coolcatlib config ...`, `/coolcatlib_client config ...`), Core's translation keys (`config.coolcatlib.*`, `tooltip.coolcatlib.*`), its payload ids and `ConfigTheme.STARFALL` (`coolcatlib:starfall`). Players and servers need the same version, as with any update.
- Nothing moved in the code: the packages are still `net.ixdarklord.coolcatcore` and `net.ixdarklord.coolcatcanvas`, and Canvas's classes keep their asset namespace (`coolcatcanvas:...`), command (`/coolcatcanvas_client`) and config files.
- Mods built for CoolCatLib: Core or Canvas have to be updated: the `coolcatcore` and `coolcatcanvas` mod ids are gone, and constructors are only read from the `coolcatlib:*` Fabric entrypoints. Depend on `coolcatlib` alone.
- Remove the CoolCatLib: Core and Canvas jars when updating: their classes are in this one. The loaders refuse to start with them installed (Forge just fails to load them).
- Maven: the artifacts are now `net.ixdarklord.coolcatlib:coolcatlib-<loader>` and hold everything. `coolcatlib-core-<loader>` and `coolcatlib-canvas-<loader>` stop at their last versions: replace both dependencies with the one.
- Canvas's earlier releases are listed in `CHANGELOG-canvas.md`.

## v2001.2.0.1 Release | Oct 4, 2026
### ✨ New Features
- Item decorators: custom drawing over an item wherever the game draws it in a GUI (inventory slots, the hotbar, a held stack), after vanilla's durability bar, cooldown and count, the same on every loader. Implement `api.item.DecoratedItem` on the item's class and hand over its `api.client.gui.ItemDecorator` in `registerDecorators(registrar)`: that's all, Core registers it by itself, on the client, the first time the item is drawn. An item's own `isBarVisible` still decides whether vanilla's bar shows under it.

## v2001.2.0.0 Release | Sep 30, 2026 (Minecraft 1.20.1 backport)
### ✨ New Features
- CoolCatLib is split in two mods: **CoolCatLib: Core** (`coolcatcore`, package `net.ixdarklord.coolcatcore`), this one, and **CoolCatLib: Canvas** (`coolcatcanvas`), which now holds screen effects, skyboxes, GUI widgets, `RenderUtils` and `Easing`. The mod id, package, asset namespace, Fabric entrypoints (`coolcatcore:common`, ...) and commands (`/coolcatcore`, `/coolcatcore_client`) all changed from `coolcatlib`.
- A cross-loader platform layer, so mods built on CoolCatLib: Core no longer need Architectury API:
  - Events (`api.event.v2`): `EventInvoker` keeps listeners in common code, ordered by `EventPhase`, and is found by its listener type (`EventInvoker.lookup(ServerTickEvents.End.class)`) or its constant (`ServerTickEvents.END`). `EventInvoker.create(Type.class)` makes a mod's own event, combining listeners by return type (`void`, `EventResult`, `EventResultHolder`, `boolean`).
  - Built-in events: server lifecycle and ticks, datapack contents sync (`ServerLifecycleEvents.SYNC_DATA_PACK_CONTENTS`: per player on login and after `/reload`), player join/leave/tick, entity load, block break/place, commands; client ticks, player join/leave, HUD rendering, item tooltips, client commands.
  - `api.registry`: `DeferredRegister` / `RegistryEntry`, `CreativeTabs`, `ReloadListeners`.
  - `api.menu.ExtendedMenus`: menu types that open with extra data.
  - `api.network.Network`: serverbound/clientbound payloads and sending. `Network.canPlayerReceive(player, type)` tells whether a player's connection accepts a payload (false for clients without the mod and for GameTest mock players).
    - Record payloads without a `StreamCodec`: `Network.registerServerbound(MyPayload.class, receiver)` (or with an explicit `Type`) derives the codec from the record's components through `PayloadCodecs`, which knows primitives, strings, common Minecraft types, enums, nested records, arrays, `Optional`, `List`, `Set`, `Map`, `Either` and `ResourceKey`. Other types are added with `PayloadCodecs.register` / `registerFactory`; registering a payload with a component type that has no codec throws right away, naming the component.
  - `api.client.registry`: key mappings, menu screens, tooltip components.
  - `api.platform.Platform`: loader, environment, mod checks, folders, the running server, fake players.
  - Mod constructors (`api.core`): `ModConstructor` (both sides), `ClientModConstructor`, `ServerModConstructor` (dedicated server) and `DataGenerationConstructor` are written once in common code, each with a construct stage and a setup stage (`DataGenerationContext.addProvider` for data providers).
    - Fabric needs no Java entry class: list them under the `coolcatcore:common`, `coolcatcore:client`, `coolcatcore:server` and `coolcatcore:datagen` entrypoints, plus `api.core.fabric.FabricDataGenerationEntrypoint` under `fabric-datagen`.
    - Forge: extend `api.core.forge.ForgeModEntrypoint` in the `@Mod` class (its constructor takes the `FMLJavaModLoadingContext` Forge passes to `@Mod` constructors) and call `common(...)`, `client(() -> ...)`, `server(() -> ...)`, `dataGeneration(...)`; the mod id comes from the context.
- `EventResult.pass()`/`interrupt()`/`allow()`/`deny()`, and `EventResultHolder.result()`/`getValue()`.
- A config system (`api.config`):
  - Declare configs with `Config.builder(modId, scope)` (typed values, nested groups, presets) or from an annotated class with `ConfigObject.register`.
  - Scopes: `CLIENT`, `COMMON`, `SERVER` (synced to players) and `WORLD` (stored per world, seeded from `defaultconfigs`, synced).
  - Types: booleans, ranged numbers (optionally sliders), strings (length/pattern), enums, colors, ids, lists, and any `Codec`; custom `ConfigType`s with their own editors.
  - TOML (default) and JSON5 files with generated comments; a config whose format changes converts its old file once (kept as `.bak`); broken files are backed up; `version`/`migration` and `aliases` handle renamed or moved settings.
  - Hot reloading of edited files, change listeners and `ConfigEvents`: `LOADED` (first read), `RELOADED` (hot reload, the reload command or `Config.reload()`), `UNLOADING` (a world config before its server's values are dropped), `VALUE_CHANGED` (each value, with its old and new value), `CHANGED` (once per batch), `SAVED` and `SYNCED`.
  - `serverOnly()` values that never leave the server; operators edit synced configs in-game with permission checks.
  - Generated config screen: search, undo/redo, reset, presets, validation, dependencies (`enabledWhen`), restart notices and list editing. Linked from the Forge mod list and Mod Menu.
  - `/coolcatcore config` (server) and `/coolcatcore_client config` (client) commands: list, get, set, reset, reload, preset, open.
  - `STARTUP` configs, read before content is registered (for item properties, which items exist...). Their values stay fixed until a restart; edits are saved for the next start. Joining a server compares them before entering the world: values must match by default (the client is offered to adopt the server's), `useServerValue()` values are taken from the server while connected, and `localOnly()` values stay per side.
  - Category popups: one category of a config in a small window with Save and Cancel, floating over the current screen or the game, e.g. `ConfigScreens.openCategory("mymod", "client/rendering")`, `ConfigScreens.categoryPopup(parent, config, path)`, or `/coolcatcore_client config open <mod> <category>` (with path suggestions). A single setting's path shows just that setting.
  - A color picker for color values (a popup with saturation/brightness, hue and alpha, hex input and dye colors), also available as `ConfigScreens.colorPicker`.
  - The main config screen (shown for every mod, even one with a single config): a header with the mod's icon (a "?" when it has none; the list of every mod's configs has its own icon), and each config as a portrait navigation card with its own artwork (faint, brightening on hover; CoolCatLib: Core's per scope, or the mod's own at `assets/<modid>/textures/gui/config/cards/<config name>.png`), its scope icon and a short label like "Server" (`config.<modid>.<name>.label`). Cards are centered, grow when hovered, and show a tooltip with the config's scope, contents, file and access. Mod Menu's CoolCatLib: Core button opens CoolCatLib: Core's own settings.
  - Page transitions: a config page's panels glide a little way into place (up from below when opened, down from above when going back, a shorter rise when opened from elsewhere) while growing from slightly smaller; the background stays still.
  - Config screen effects: animations a theme names by id, drawn behind the panels, over the whole screen, and over each widget (buttons, toggles, sliders, text fields, cards, popup panels). Mods register their own on the client with `ConfigEffects.register(id, ConfigEffect)` and use them with `ConfigTheme.Builder.effects(...)`, `ConfigBuilder.effects(...)` for one config, or `"effects"` in `config_theme.json`; an unknown id is skipped and an effect that throws is switched off, each logged once. The built-in `ConfigTheme.STARFALL`, every theme's default, draws soft glows in the accent and small faint stars falling from the top, shifting with the mouse by depth (parallax). CoolCatLib: Core's client config turns effects and the page transitions on or off (Effects > Theme Effects / Page Transitions); both are always off on the Fast graphics preset.
  - Redesigned config screens: a top bar (title, scope badges, search), a category sidebar, settings with descriptions and nested sections, and a bottom bar with the unsaved-changes status and actions; toggle switches, sliders, selectors and flat buttons; presets, confirmations and the color picker as popups. Icons are 64x64 textures in `assets/coolcatcore/textures/gui/config/icons/` (smoothly filtered), replaceable by resource packs.
  - `ConfigTheme`: each mod's own look, set per mod (`ConfigTheme.setForMod`) or per config (`ConfigBuilder.theme` / `background`): a full `ConfigColorScheme` (presets `DARK`, `LIGHT`, and `tinted(accent)` for the dark scheme shaded toward the mod's color), a background texture by its path (cover, stretch or tile), the texture's opacity (`textureOpacity`, letting the panorama or world show through) and the backdrop color's opacity over the background (`backgroundOpacity`). Players can scale both for every mod in CoolCatLib: Core's client config (Background > Backdrop Opacity / Texture Opacity). By default the screens are see-through to the title panorama or the world. Resource packs can restyle a mod with `assets/<modid>/coolcatcore/config_theme.json`.
  - Popup panel sprites: `ConfigTheme.Builder.popupSprite` (or `popup_sprite` in `config_theme.json`) draws a nine-slice GUI sprite as the panel of popups (category popups, confirmations, the color picker) instead of the flat panel, and `ConfigScreens.categoryPopup(parent, config, path, theme)` opens a category popup with its own theme, e.g. to match the screen it's opened from.
    - Toggle switches have an outline on their track: the panel border while off, a darker shade of the accent as they turn on.
    - Popups keep their buttons in a footer strip along the bottom and their content above it, so a sprite's footer band sits behind the buttons only (the color picker's Cancel and Done moved there).
  - The config list shows each mod's icon (a theme can set another); config pages and their cards show an icon of their kind (client, common, server, world, startup).
  - `Platform.getModName`.
  - Dark and light mode: a sun/moon switch in every config screen's top bar, remembered in CoolCatLib: Core's own client config (`themeMode`). Each theme has a light scheme too (`ConfigTheme.Builder.lightColors`, by default derived from the mod's accent; `light_base`/`light_colors` in `config_theme.json`).
  - The main config screen's search bar searches every config it lists (names, keys, comments, group names, values), with results grouped by config; opening a result shows that config filtered to it. A config's own search covers only that config.
- Attachments, containers and handlers for items, blocks and entities:
  - `api.attachment`: typed data any entity (players included), block entity or item stack can carry. Each mod creates its own `AttachmentRegistry.create(modId)` (and calls `register()` while it initialises); its values are stored under its own id, in the `<modid>:attachments` item component and a `<modid>:attachments` tag in entity and block entity data. Declared once (`ATTACHMENTS.builder(name, codec, default)`), then used as `MADNESS.get(player)`, `set`, `update`, `modify`, `reset`, or through `AttachmentHolder.of(...)`.
    - Persistent attachments save with their holder; `transientBuilder` ones never do. `copyOnDeath()` keeps a player's value through death (always kept through dimension changes and the End exit); `keepOnDrop()` carries a block entity's value into its dropped item and back when placed.
    - `sync(SyncPolicy)`: `SELF` (the player it belongs to), `TRACKING`, `ALL`, or any predicate. Only changed values are sent, at most once per tick; everything when a player starts seeing the holder, receives its chunk, joins, respawns or changes dimension.
    - On item stacks, defaults aren't stored, so stacks still stack.
  - `AttachmentEvents`: `CHANGING` (cancel a change or replace the value), `ADDED`, `CHANGED` (in-place changes included), `REMOVED`, `START_TRACKING`/`STOP_TRACKING` (a player starts or stops receiving a holder's data) and `RECEIVED` (synced values arrived on the client), plus typed per-attachment helpers (`onChanged(MADNESS, ...)`).
  - `api.container`: `ContainerLayout` (slot filters, limits, roles `STORAGE`/`INPUT`/`OUTPUT`/`INTERNAL`, which slots each face reaches) makes `SlotContainer`s, vanilla `Container`s with insert/extract, listeners and layout-aware menu slots. `AttachmentRegistry.container` stores one on any entity or block entity (saved and synced with the rest); `ItemContainers` keeps one in a stack (`ContainerItem` for items that have one); `ItemTransfer` moves items between any containers through faces.
  - `api.block`: `ExtendedBlockEntity` (attachment shortcuts, handlers, `serverTick`/`clientTick` with `ExtendedBlockEntity.ticker`) and `ExtendedContainerBlockEntity` (an inventory hoppers and comparators use; contents spill or, with `keepContentsOnBreak`, stay in the item).
  - `api.handler`: `HandlerType` for anything holders hand out (inventories, energy...), from the holder itself (`HandlerProvider`, `HandlerMap`) or registered providers and fallbacks for blocks, block entities, entities and items. `HandlerTypes.CONTAINER` also finds vanilla containers (double chests as one). `BlockHandlerCache` keeps a lookup until the block changes, its block entity goes, or `HandlerType.invalidate` is called.
  - Other mods reach these containers through each loader's own system, following the layout's filters, roles and limits: Forge item handler capabilities (`ForgeCapabilities.ITEM_HANDLER` on block entities, entities and `ContainerItem` stacks) and Fabric's Transfer API (`ItemStorage.SIDED` for blocks).
  - `api.registry.BlockEntityTypes.create`: block entity types from common code.
  - Storage menus (`api.menu.StorageMenuDefinition`): a menu for a block's or an item's inventory, declared once (`StorageMenuDefinition.grid(columns, rows)` or placed slot by slot), registered with `createMenuType` and opened with `open(player, blockEntity, title)` or `open(player, hand, title)`. Slots follow the container's layout and shift-click; the menu closes when the block is removed, the player walks away, or the item leaves its slot (which stays locked meanwhile). `sync(attachment)` and `syncValue(...)` send extra values to the screen while it's open, and `button(id, action)` runs screen buttons on the server. `api.client.gui.screens.StorageScreen` draws any of these menus with no texture, and can be extended.

### ⚙️ Refactoring
- Rewrote the v2 event system (the lookup-based skeleton had no events); `EventInvokerRegistry` was removed.

### 🔁 Differences from the 26.1.2 version (Minecraft 1.20.1)
- Built for Forge 47 and Fabric (Fabric API 0.92.6) on Java 17, with the same features as CoolCatLib: Core for 26.1.2, except where 1.20.1 has no equivalent:
  - Networking: 1.20.1 has no payload types, so Core brings its own `api.network.CustomPacketPayload` and the `api.network.codec` package (`StreamCodec`, `ByteBufCodecs`, ...; `ByteBufCodecs` also holds the codecs newer Minecraft keeps on vanilla classes, such as `RESOURCE_LOCATION`, `BLOCK_POS`, `ITEM_STACK`, `COMPONENT`). On Forge every payload travels on one `coolcatcore:network` channel; on Fabric each payload type is its own channel.
  - There is no configuration phase: configuration payloads (config sync and the `STARTUP` config check) are sent in the login phase instead.
  - `api.utils.ARGB`: the packed colour helpers newer Minecraft has as `net.minecraft.util.ARGB`.
  - GUI: everything draws with `GuiGraphics`; methods named `extract...` on 26.1.2 are `render...` again (`StyledScreen.renderBackground/renderPanels/renderTitle`, `StyledPopup.renderPopup`, `FlatButton.renderContents`, `StorageScreen.renderPanel`, `ConfigEffect.renderBackground/renderForeground/renderWidget`), and input uses 1.20.1's `mouseClicked(double, double, int)`, `keyPressed(int, int, int)`, ... signatures. GUI sprites (config theme popup sprites included) are textures under `textures/gui/sprites/`, with their stretch, tile or nine-slice scaling read from the `.mcmeta`; a theme's `popupSprite` may also be a `.png` texture path. The menu blur is always on, at the default strength. Config screen effects and page transitions are off on the "Fast" graphics setting (1.20.1's equivalent of the Fast graphics preset).
  - Events: `ClientGuiEvents` HUD listeners take `(GuiGraphics, float partialTick)`; `ItemTooltipEvents` has no tooltip context.
  - Attachments: item stack values live in the stack's NBT (`"<modid>:attachments"`), not in a data component (`AttachmentRegistry.componentType()`/`bundleComponent()` don't exist). `keepOnDrop` values reach the dropped block item through the loot table: `AttachmentRegistry.copyKeptOnDrop()` gives the `copy_nbt` function.
  - Containers: `SlotContainer.toContents/fromContents` use a `CompoundTag` (a vanilla `Items` list); `ItemContainers` keeps contents in `BlockEntityTag.Items` for block items and `Items` for other items. Blocks of an `ExtendedContainerBlockEntity` call `ExtendedContainerBlockEntity.onBlockRemoved(state, level, pos, newState)` from `onRemove` so the contents spill, and a `keepContentsOnBreak` layout needs a `copy_nbt` of `Items` into `BlockEntityTag.Items` in the loot table. There's no Fabric item storage lookup for `ContainerItem` stacks.
  - Config: `ConfigBuilder.editPermission(int level)` / `Config.editPermission()` use a permission level (default 2) instead of a `Permission`.
  - `ItemDataComponent(ResourceLocation, Codec)` and `DataComponent` are backed by the stack's NBT.
  - Brewing: `BrewingBuilder` takes `Potion`s; `RegisterBrewingRecipesEvent.invokeEvent()` takes no builder and fires once per game. On Fabric, custom recipes are read through `api.brewing.fabric.FabricBrewingRecipes` (the `PotionBrewingExt`/`PotionBrewingBuilderExt` interfaces don't exist on 1.20.1).
  - `FabricLanguageWrapper` takes a `FabricDataOutput`.
  - `Platform.isForge()` and `Platform.Loader.FORGE` instead of `isNeoForge()`/`NEOFORGE`.
- Carries the brewing fix of v2001.1.0.1: `RegisterBrewingRecipesEvent` fires during Forge's common setup.

## v2001.1.0.1 Release | Jul 9, 2026
### 🐛 Bug Fixes & Improvements
- Resolved an issue where the RegisterBrewingRecipesEvent was not being triggered correctly.

## v2001.1.0.0 Release | Oct 30, 2025
### ⚙️ Refactoring
- Renamed and reorganized several classes.
- Updated version formatting from X.X.X to MCVR.X.X.X to clearly distinguish between Minecraft release versions.

### ✨ New Feature
- Added Language Data Generator to support shared environments.

## v1.0.3 Release | Feb 19, 2024
### Fixed
- [CCL-1] [Fabric] Incompatibility with KubeJS

## v1.0.2 Release | Dec 27, 2023
### Adding
- [Fabric] Conditional Recipes
- Improving the TomlConfigReader class

## v1.0.1 Release | Nov 8, 2023
### Adding
- Adding Arabic Translation
- More methods in ScreenUtils class
- Moving and rename some of the packages and classes

## v1.0.0 Release | Oct 9, 2023
- Port to 1.20.1
