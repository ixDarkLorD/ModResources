package net.ixdarklord.folios.internal.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.MapCodec;
import net.ixdarklord.folios.api.FoliosFormat;
import net.ixdarklord.folios.api.client.FoliosBook;
import net.ixdarklord.folios.api.client.FoliosReveal;
import net.ixdarklord.folios.api.client.FoliosReveals;
import net.ixdarklord.folios.api.client.FoliosCategory;
import net.ixdarklord.folios.api.client.FoliosEntry;
import net.ixdarklord.folios.api.client.FoliosLock;
import net.ixdarklord.folios.api.client.FoliosStyles;
import net.ixdarklord.folios.api.client.page.FoliosIcon;
import net.ixdarklord.folios.api.client.page.FoliosLayout;
import net.ixdarklord.folios.api.client.page.FoliosPageElement;
import net.ixdarklord.folios.api.client.page.FoliosPageElements;
import net.ixdarklord.folios.api.client.page.FoliosText;
import net.ixdarklord.folios.internal.client.handheld.CoverModel;
import net.ixdarklord.folios.internal.client.page.ElementLayout;
import net.ixdarklord.folios.internal.client.page.Observed;
import net.ixdarklord.folios.internal.client.page.Sprites;
import net.ixdarklord.folios.internal.client.page.TextPage;
import net.ixdarklord.folios.internal.client.paint.BakedFills;
import net.ixdarklord.folios.internal.format.BookUpgrader;
import net.ixdarklord.folios.internal.client.page.ErrorPage;
import net.ixdarklord.folios.internal.core.Folios;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;

import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class FoliosLibrary {
    private static final FileToIdConverter FILES = FileToIdConverter.json("folios");
    private static final int DEFAULT_ACCENT = 0x8B6CFF;
    private static final int DEFAULT_COVER = 0x3A2E58;
    private static final float DEFAULT_TILT = 6.0F;
    private static final float DEFAULT_DISTANCE = 0.64F;

    private static Map<ResourceLocation, FoliosBook> books = Map.of();
    private static Map<ResourceLocation, JsonObject> builds = Map.of();
    private static Map<ResourceLocation, Credits> credits = Map.of();
    private static Map<ResourceLocation, FoliosIcon> coverIcons = Map.of();
    private static Map<ResourceLocation, Float> coverIconSizes = Map.of();
    private static Map<ResourceLocation, ElementLayout> layouts = Map.of();
    private static Map<ResourceLocation, CelebrationSettings> celebrations = Map.of();
    private static final Map<ResourceLocation, FoliosSession> SESSIONS = new HashMap<>();
    private static final Map<ResourceLocation, FoliosSession> LARGER = new HashMap<>();

    private FoliosLibrary() {}

    public static @Nullable FoliosBook book(ResourceLocation id) {
        return books.get(id);
    }

    public static Map<ResourceLocation, FoliosBook> books() {
        return books;
    }

    public static @Nullable Component credit(ResourceLocation book) {
        Credits given = credits.get(book);
        List<Component> names = new ArrayList<>();
        if (given != null) for (String author : given.authors()) names.add(FoliosText.inline(author));
        if (names.isEmpty()) {
            String key = textKey(book, "credits.authors");
            if (!FoliosText.hasTranslation(key)) key = textKey(book, "author");
            if (!FoliosText.hasTranslation(key)) return null;
            names.add(FoliosText.inline(key));
        }
        Component prefix;
        if (given != null && given.prefix() != null) prefix = FoliosText.inline(given.prefix());
        else {
            String key = textKey(book, "credits.prefix");
            prefix = FoliosText.hasTranslation(key) ? FoliosText.inline(key) : Component.translatableWithFallback("folios.guide_book.written_by", "Written by");
        }
        return Component.translatableWithFallback("folios.guide_book.credit", "%s %s", prefix, joined(names));
    }

    private static FoliosIcon coverIcon(JsonElement json) {
        if (json.isJsonPrimitive() && json.getAsString().equals("none")) return FoliosIcon.NONE;
        return FoliosIcon.read(json);
    }

    private static Component joined(List<Component> names) {
        Component all = names.get(0);
        for (int index = 1; index < names.size() - 1; index++) all = Component.translatableWithFallback("folios.list.comma", "%s, %s", all, names.get(index));
        if (names.size() > 1) all = Component.translatableWithFallback("folios.list.and", "%s and %s", all, names.get(names.size() - 1));
        return all;
    }

    private record Credits(List<String> authors, @Nullable String prefix) {
        static Credits read(JsonObject json) {
            List<String> authors = new ArrayList<>();
            JsonElement written = json.get("authors");
            if (written != null && written.isJsonArray()) for (JsonElement author : written.getAsJsonArray()) authors.add(FoliosText.read(author));
            else if (written != null && !written.isJsonNull()) authors.add(FoliosText.read(written));
            return new Credits(authors, json.has("prefix") ? FoliosText.read(json.get("prefix")) : null);
        }
    }

    public static FoliosIcon coverIcon(ResourceLocation book) {
        return coverIcons.getOrDefault(book, FoliosIcon.NONE);
    }

    public static float coverIconSize(ResourceLocation book) {
        return coverIconSizes.getOrDefault(book, 1.0F);
    }

    public static String textKey(ResourceLocation book, String what) {
        return "folios." + book.getNamespace() + "." + book.getPath().replace('/', '.') + "." + what;
    }

    public static CelebrationSettings celebrations(ResourceLocation book) {
        return celebrations.getOrDefault(book, CelebrationSettings.OFF);
    }

    public static @Nullable JsonObject build(ResourceLocation id) {
        return builds.get(id);
    }

    public static @Nullable FoliosSession session(ResourceLocation id) {
        FoliosBook book = books.get(id);
        if (book == null) return null;
        FoliosSession session = SESSIONS.get(id);
        if (session == null || !session.isCurrent()) {
            if (session != null) session.close();
            session = new FoliosSession(book);
            SESSIONS.put(id, session);
        }
        return session;
    }

    public static @Nullable FoliosSession session(ResourceLocation id, int width, int height) {
        if (width <= FoliosLayout.PAGE_WIDTH && height <= FoliosLayout.PAGE_HEIGHT) return session(id);
        FoliosBook book = books.get(id);
        if (book == null) return null;
        FoliosSession session = LARGER.get(id);
        if (session == null || !session.isCurrent() || session.layout().pageWidth() != width || session.layout().pageHeight() != height) {
            if (session != null) session.close();
            session = new FoliosSession(book, width, height);
            LARGER.put(id, session);
        }
        return session;
    }

    public static void reload(ResourceManager manager) {
        Sprites.clear();
        BakedFills.clear();
        CoverModel.clear();
        CoverMarkers.clear();
        ObtainedItems.clear();
        Map<ResourceLocation, JsonObject> bookFiles = new LinkedHashMap<>();
        Map<ResourceLocation, Map<String, JsonObject>> parts = new HashMap<>();
        for (Map.Entry<ResourceLocation, Resource> file : FILES.listMatchingResources(manager).entrySet()) {
            ResourceLocation id = FILES.fileToId(file.getKey());
            String path = id.getPath();
            JsonObject json;
            try (Reader reader = file.getValue().openAsReader()) {
                JsonElement element = JsonParser.parseReader(reader);
                if (!element.isJsonObject()) throw new IllegalStateException("not a JSON object");
                json = element.getAsJsonObject();
            } catch (Exception e) {
                Folios.LOGGER.error("Couldn't read the guide file {}: {}", file.getKey(), e.getMessage());
                continue;
            }
            if (path.endsWith("/book")) {
                bookFiles.put(id.withPath(path.substring(0, path.length() - 5)), json);
                continue;
            }
            int categories = path.indexOf("/categories/");
            int entries = path.indexOf("/entries/");
            int buildsAt = path.indexOf("/builds/");
            int at;
            if (buildsAt > 0 && (categories < 0 || buildsAt < categories) && (entries < 0 || buildsAt < entries)) at = buildsAt;
            else if (categories > 0 && (entries < 0 || categories < entries)) at = categories;
            else if (entries > 0) at = entries;
            else continue;
            parts.computeIfAbsent(id.withPath(path.substring(0, at)), book -> new LinkedHashMap<>()).put(path.substring(at + 1) + ".json", json);
        }
        Map<ResourceLocation, FoliosBook> loaded = new LinkedHashMap<>();
        Map<ResourceLocation, JsonObject> buildFiles = new HashMap<>();
        Map<ResourceLocation, Credits> credited = new HashMap<>();
        Map<ResourceLocation, FoliosIcon> emblems = new HashMap<>();
        Map<ResourceLocation, Float> emblemSizes = new HashMap<>();
        Map<ResourceLocation, ElementLayout> setting = new HashMap<>();
        Map<ResourceLocation, CelebrationSettings> celebrating = new HashMap<>();
        for (Map.Entry<ResourceLocation, JsonObject> file : bookFiles.entrySet()) {
            ResourceLocation id = file.getKey();
            try {
                Map<String, JsonObject> files = new LinkedHashMap<>();
                files.put("book.json", file.getValue());
                files.putAll(parts.getOrDefault(id, Map.of()));
                files = current(id, files);
                JsonObject book = files.get("book.json");
                if (book.has("credits") && book.get("credits").isJsonObject()) credited.put(id, Credits.read(book.getAsJsonObject("credits")));
                if (book.get("cover") instanceof JsonObject cover) {
                    if (cover.has("icon")) emblems.put(id, coverIcon(cover.get("icon")));
                    if (cover.has("icon_size")) emblemSizes.put(id, Mth.clamp(cover.get("icon_size").getAsFloat(), 0.25F, 2.0F));
                }
                setting.put(id, ElementLayout.read(book, "The guide " + id));
                Map<String, JsonObject> categories = new LinkedHashMap<>();
                Map<String, JsonObject> entries = new LinkedHashMap<>();
                files.forEach((path, json) -> {
                    String name = path.substring(0, path.length() - 5);
                    if (name.startsWith("categories/")) categories.put(name.substring(11), json);
                    else if (name.startsWith("entries/")) entries.put(name.substring(8), json);
                    else if (name.startsWith("builds/")) buildFiles.put(id.withPath(id.getPath() + "/" + name), json);
                });
                loaded.put(id, readBook(id, book, categories, entries));
                celebrating.put(id, CelebrationSettings.read(book.get("celebrations")));
            } catch (Exception e) {
                Folios.LOGGER.error("Couldn't load the guide {}: {}", id, e.getMessage());
            }
        }
        for (ResourceLocation orphan : parts.keySet()) {
            if (!bookFiles.containsKey(orphan)) Folios.LOGGER.warn("Guide files for {} have no book.json beside them", orphan);
        }
        books = Map.copyOf(loaded);
        builds = Map.copyOf(buildFiles);
        credits = Map.copyOf(credited);
        coverIcons = Map.copyOf(emblems);
        coverIconSizes = Map.copyOf(emblemSizes);
        layouts = Map.copyOf(setting);
        celebrations = Map.copyOf(celebrating);
        SESSIONS.values().forEach(FoliosSession::close);
        SESSIONS.clear();
        LARGER.values().forEach(FoliosSession::close);
        LARGER.clear();
        if (!loaded.isEmpty()) Folios.LOGGER.info("Loaded {} guide book(s)", loaded.size());
    }

    private static Map<String, JsonObject> current(ResourceLocation id, Map<String, JsonObject> files) {
        JsonObject book = files.get("book.json");
        String format = FoliosFormat.LEGACY;
        JsonElement named = book.get("format_version");
        if (named == null) {
            Folios.LOGGER.warn("The guide {} is in the Folios 2.x format; update it with the book upgrader on the Folios docs site", id);
        } else if (!named.isJsonPrimitive() || FoliosFormat.parse(named.getAsString()) == null) {
            Folios.LOGGER.error("The guide {} has the \"format_version\" {}, which isn't a version such as \"{}\"; it is read in the format of Folios 2.x",
                    id, named, FoliosFormat.CURRENT);
        } else {
            String version = named.getAsString();
            if (FoliosFormat.isNewer(version)) {
                Folios.LOGGER.error("The guide {} is written for Folios {} or newer; this is Folios {}, so parts of it may not be read as meant",
                        id, version, FoliosFormat.RELEASE);
            }
            format = FoliosFormat.of(version);
        }
        if (FoliosFormat.compare(format, FoliosFormat.CURRENT) < 0) {
            return BookUpgrader.upgrade(id.toString(), files, format, FoliosFormat.CURRENT).files();
        }
        Map<String, List<String>> old = BookUpgrader.check(id.toString(), files, FoliosFormat.CURRENT);
        if (!old.isEmpty()) {
            StringBuilder list = new StringBuilder();
            old.forEach((path, lines) -> lines.forEach(line -> list.append(System.lineSeparator()).append("  ").append(path).append(": ").append(line)));
            Folios.LOGGER.error("The guide {} is written in format {} but still has the shape of an older one in places; these are left out "
                    + "until they are written as the format has them (the book upgrader on the docs site, {}, lists them too; how each is "
                    + "written now: {}){}", id, FoliosFormat.CURRENT, UPGRADER, MIGRATION, list);
        }
        return files;
    }

    private static String bookText(ResourceLocation id, JsonObject json, String key, String fallback) {
        if (json.has(key) && !json.get(key).isJsonNull()) return FoliosText.read(json.get(key));
        return FoliosText.translation(textKey(id, key), List.of(), fallback);
    }

    public static ElementLayout layoutOf(ResourceLocation book) {
        return layouts.getOrDefault(book, ElementLayout.NONE);
    }

    public static final String MIGRATION = "https://ixdarklord.github.io/Folios/docs/migrating-to-3.0/";
    public static final String UPGRADER = "https://ixdarklord.github.io/Folios/upgrader/";

    private static FoliosBook readBook(ResourceLocation id, JsonObject json, Map<String, JsonObject> categoryFiles, Map<String, JsonObject> entryFiles) {
        String name = bookText(id, json, "name", id.toString());
        ResourceLocation style = json.has("style") ? FoliosStyles.id(json.get("style").getAsString()) : FoliosStyles.SCREEN;
        List<FoliosCategory> categories = new ArrayList<>();
        for (Map.Entry<String, JsonObject> file : categoryFiles.entrySet()) {
            try {
                JsonObject category = file.getValue();
                String key = textKey(id, "category." + file.getKey().replace('/', '.'));
                categories.add(new FoliosCategory(file.getKey(), text(category, "name", key + ".name", file.getKey()),
                        text(category, "description", key + ".description", ""), FoliosIcon.read(category.get("icon")),
                        integer(category, "sort", 0), FoliosLock.read(category, id), color(category, "color", -1)));
            } catch (Exception e) {
                Folios.LOGGER.error("Couldn't load the category {} of the guide {}: {}", file.getKey(), id, e.getMessage());
            }
        }
        List<FoliosEntry> entries = new ArrayList<>();
        for (Map.Entry<String, JsonObject> file : entryFiles.entrySet()) {
            try {
                FoliosEntry entry = readEntry(id, file.getKey(), file.getValue());
                if (categories.stream().noneMatch(category -> category.id().equals(entry.category()))) {
                    Folios.LOGGER.warn("The entry {} of the guide {} is in the category {}, which the book doesn't have", entry.id(), id, entry.category());
                    continue;
                }
                entries.add(entry);
            } catch (Exception e) {
                Folios.LOGGER.error("Couldn't load the entry {} of the guide {}: {}", file.getKey(), id, e.getMessage());
            }
        }
        JsonObject cover = json.has("cover") ? json.getAsJsonObject("cover") : new JsonObject();
        JsonObject handheld = json.has("handheld") ? json.getAsJsonObject("handheld") : new JsonObject();
        return new FoliosBook(id, name, bookText(id, json, "subtitle", ""), bookText(id, json, "landing", ""), style,
                color(json, "accent", DEFAULT_ACCENT), color(cover, "color", DEFAULT_COVER),
                cover.has("texture") ? ResourceLocation.parse(cover.get("texture").getAsString()) : null,
                json.has("icon") ? FoliosIcon.read(json.get("icon")) : ownItem(id),
                models(json, cover),
                !json.has("show_progress") || json.get("show_progress").getAsBoolean(),
                handheld.has("tilt") ? Mth.clamp(handheld.get("tilt").getAsFloat(), -45.0F, 80.0F) : DEFAULT_TILT,
                handheld.has("distance") ? Mth.clamp(handheld.get("distance").getAsFloat(), 0.3F, 1.5F) : DEFAULT_DISTANCE,
                handheld.has("page_turn") ? FoliosBook.PageTurn.valueOf(handheld.get("page_turn").getAsString().toUpperCase(Locale.ROOT)) : FoliosBook.PageTurn.BEND,
                json.has("reveal") ? reveal(json.get("reveal")) : FoliosReveals.DEFAULT,
                textures(json.has("textures") ? json.getAsJsonObject("textures") : new JsonObject()),
                layout(json.has("layout") ? json.getAsJsonObject("layout") : new JsonObject()),
                json.has("close_on_click_outside") ? json.get("close_on_click_outside").getAsBoolean() : style.equals(FoliosStyles.HANDHELD),
                handling(handheld),
                colors(json.has("colors") ? json.getAsJsonObject("colors") : new JsonObject(), json.get("panel")),
                coverText(cover.has("text") ? cover.getAsJsonObject("text") : new JsonObject(), bookText(id, json, "summary", "")),
                categoryView(id, json.has("categories") ? json.getAsJsonObject("categories") : new JsonObject()),
                json.has("progress_scope") && json.get("progress_scope").getAsString().equals("copy") ? FoliosBook.Progress.BOOK : FoliosBook.Progress.PLAYER,
                categories, entries);
    }

    private static final Set<String> PAGE_COLORS = Set.of("paper", "text", "muted", "heading", "accent", "link", "panel", "line");

    private static final Set<String> PANEL_COLORS = Set.of("background", "frame", "title", "detail");

    private static FoliosBook.Colors colors(JsonObject json, @Nullable JsonElement panel) {
        Map<String, Integer> panelColors = panel != null && panel.isJsonObject() ? named(panel.getAsJsonObject(), PANEL_COLORS) : Map.of();
        return new FoliosBook.Colors(named(json, PAGE_COLORS), json.has("dark") ? named(json.getAsJsonObject("dark"), PAGE_COLORS) : Map.of(), panelColors);
    }

    private static Map<String, Integer> named(JsonObject json, Set<String> names) {
        Map<String, Integer> colors = new HashMap<>();
        for (String name : names) {
            Integer value = argb(json, name);
            if (value != null) colors.put(name, value);
        }
        return Map.copyOf(colors);
    }

    private static FoliosBook.CoverText coverText(JsonObject json, String summary) {
        return new FoliosBook.CoverText(line(json, "title", FoliosBook.CoverText.TITLE), line(json, "subtitle", FoliosBook.CoverText.SUBTITLE),
                line(json, "summary", FoliosBook.CoverText.SUBTITLE), summary);
    }

    private static FoliosBook.CoverText.@Nullable Line line(JsonObject json, String key, FoliosBook.CoverText.Line fallback) {
        if (!json.has(key)) return null;
        JsonObject line = json.getAsJsonObject(key);
        return new FoliosBook.CoverText.Line(
                line.has("x") ? line.get("x").getAsFloat() : fallback.x(),
                line.has("y") ? line.get("y").getAsFloat() : fallback.y(),
                line.has("size") ? Mth.clamp(line.get("size").getAsFloat(), 0.1F, 4.0F) : fallback.size(),
                line.has("width") ? Mth.clamp(line.get("width").getAsFloat(), 0.5F, 16.0F) : fallback.width());
    }

    private static FoliosBook.Handling handling(JsonObject json) {
        return new FoliosBook.Handling(!json.has("look_around") || json.get("look_around").getAsBoolean(),
                !json.has("walk") || json.get("walk").getAsBoolean());
    }

    private static FoliosBook.CategoryView categoryView(ResourceLocation id, JsonObject json) {
        String view = json.has("view") ? json.get("view").getAsString() : "list";
        String overflow = json.has("overflow") ? json.get("overflow").getAsString() : "pages";
        if (!view.equals("list") && !view.equals("grid")) Folios.LOGGER.warn("The guide {} has categories \"view\": \"{}\", which is list or grid", id, view);
        if (!overflow.equals("pages") && !overflow.equals("scroll")) Folios.LOGGER.warn("The guide {} has categories \"overflow\": \"{}\", which is pages or scroll", id, overflow);
        return new FoliosBook.CategoryView(view.equals("grid"), overflow.equals("scroll"));
    }

    private static final ThreadLocal<ResourceLocation> READING = new ThreadLocal<>();

    public static @Nullable ResourceLocation reading() {
        return READING.get();
    }

    private static FoliosEntry readEntry(ResourceLocation book, String id, JsonObject json) {
        READING.set(book);
        try {
            return readEntryIn(book, id, json);
        } finally {
            READING.remove();
        }
    }

    private static FoliosEntry readEntryIn(ResourceLocation book, String id, JsonObject json) {
        String category = id.contains("/") ? id.substring(0, id.indexOf('/')) : "";
        List<FoliosEntry.Page> pages = new ArrayList<>();
        List<FoliosEntry.Listing> listings = new ArrayList<>();
        boolean listAll = json.has("index") && json.get("index").isJsonPrimitive() && json.get("index").getAsString().equals("elements");
        if (json.has("index") && !listAll) {
            Folios.LOGGER.warn("The entry {} of the guide {} has \"index\": {}; an entry takes \"index\": \"elements\", to list its elements", id, book, json.get("index"));
        }
        if (json.has("pages")) {
            int index = pages.size();
            for (JsonElement page : json.getAsJsonArray("pages")) {
                JsonObject object = page.isJsonObject() ? page.getAsJsonObject() : null;
                if (object != null && object.has("anchor") && !ANCHORS.contains(object.get("anchor").getAsString())) {
                    Folios.LOGGER.error("Page {} of the entry {} of the guide {} has \"anchor\": \"{}\", which places a page's content (top, center or bottom); "
                            + "to name the page for links, use \"marker\": \"{}\"", index + 1, id, book, object.get("anchor").getAsString(), object.get("anchor").getAsString());
                    object = object.deepCopy();
                    object.remove("anchor");
                    page = object;
                }
                FoliosEntry.Page read = new FoliosEntry.Page(readPage(book, id, index, page),
                        object != null && object.has("marker") ? object.get("marker").getAsString() : null,
                        object != null ? FoliosLock.read(object, book) : FoliosLock.NONE, object != null ? pageIcon(object.get("icon")) : null);
                pages.add(read);
                if (object != null) listings.addAll(listings(book, id, index, object, read, listAll));
                index++;
            }
        }
        return new FoliosEntry(id, category, text(json, "name", textKey(book, "entry." + id.replace('/', '.')) + ".name", id), FoliosIcon.read(json.get("icon")),
                integer(json, "sort", 0), json.has("featured") && json.get("featured").getAsBoolean(), FoliosLock.read(json, book), pages,
                json.has("reveal") ? reveal(json.get("reveal")) : null, listings);
    }

    private static List<FoliosEntry.Listing> listings(ResourceLocation book, String entry, int index, JsonObject page, FoliosEntry.Page read, boolean all) {
        List<FoliosEntry.Listing> found = new ArrayList<>();
        String where = "page " + (index + 1) + " of the entry " + entry + " of the guide " + book;
        boolean ofElements = page.has("elements") && page.get("elements").isJsonArray()
                && read.page() instanceof TextPage;
        FoliosEntry.Listing own = listing(page, index, -1, read.page(), List.of(read.lock()), all && !ofElements, "P" + where.substring(1));
        if (own != null) found.add(own);
        if (ofElements && read.page() instanceof TextPage text) {
            var elements = page.getAsJsonArray("elements");
            for (int at = 0; at < elements.size() && at < text.elements().size(); at++) {
                if (!elements.get(at).isJsonObject()) continue;
                var item = text.elements().get(at);
                FoliosEntry.Listing listing = listing(elements.get(at).getAsJsonObject(), index, at, item.element(), List.of(read.lock(), item.lock()), all,
                        "Element " + (at + 1) + " of " + where);
                if (listing != null) found.add(listing);
            }
        }
        return found;
    }

    private static FoliosEntry.@Nullable Listing listing(JsonObject json, int page, int element, FoliosPageElement shown, List<FoliosLock> locks,
                                                         boolean byDefault, String where) {
        String title = json.has("title") && json.get("title").isJsonPrimitive() ? json.get("title").getAsString() : null;
        if (!json.has("index")) {
            boolean worth = title != null && !title.isEmpty() || !shown.items().isEmpty();
            return byDefault && worth ? new FoliosEntry.Listing(null, null, page, element, title, shown, locks) : null;
        }
        JsonElement index = json.get("index");
        if (index.isJsonPrimitive() && index.getAsJsonPrimitive().isBoolean()) {
            return index.getAsBoolean() ? new FoliosEntry.Listing(null, null, page, element, title, shown, locks) : null;
        }
        if (!index.isJsonObject()) {
            Folios.LOGGER.warn("{} has \"index\": {}, which is true, false or {{\"name\": ..., \"icon\": ...}}", where, index);
            return null;
        }
        JsonObject named = index.getAsJsonObject();
        String name = named.has("name") ? named.get("name").getAsString() : null;
        FoliosIcon icon = named.has("icon") ? pageIcon(named.get("icon")) : null;
        return new FoliosEntry.Listing(name, icon, page, element, title, shown, locks);
    }

    private static final Set<String> ANCHORS = Set.of("top", "center", "bottom");

    private static @Nullable FoliosIcon pageIcon(@Nullable JsonElement json) {
        if (json == null || json.isJsonNull()) return null;
        if (json.isJsonPrimitive() && json.getAsString().equals("none")) return FoliosIcon.NONE;
        try {
            return FoliosIcon.read(json);
        } catch (Exception e) {
            Folios.LOGGER.warn("A page names an icon it can't read, {}: {}", json, e.getMessage());
            return null;
        }
    }

    private static FoliosPageElement readPage(ResourceLocation book, String entry, int index, JsonElement json) {
        try {
            JsonObject object;
            if (json.isJsonPrimitive()) {
                object = new JsonObject();
                object.addProperty("text", json.getAsString());
            } else {
                object = json.getAsJsonObject();
            }
            ResourceLocation type = FoliosPageElements.id(object.has("type") ? object.get("type").getAsString() : "text");
            MapCodec<? extends FoliosPageElement> codec = FoliosPageElements.get(type);
            if (codec == null) throw new IllegalArgumentException("no page type " + type);
            FoliosPageElement page = codec.codec().parse(JsonOps.INSTANCE, object).getOrThrow(IllegalArgumentException::new);
            var settings = ElementLayout.read(object, "Page " + (index + 1) + " of the entry " + entry + " of the guide " + book);
            var observed = Observed.read(object);
            if (page instanceof TextPage text) return text.with(settings, observed);
            return page.spread() ? page : TextPage.single(page, settings, observed);
        } catch (Exception e) {
            Folios.LOGGER.error("Couldn't read page {} of the entry {} of the guide {}: {}", index + 1, entry, book, e.getMessage());
            return new ErrorPage("Page " + (index + 1) + " couldn't be read: " + e.getMessage());
        }
    }

    private static FoliosBook.Models models(JsonObject book, JsonObject coverGroup) {
        JsonObject json = book.has("models") ? book.getAsJsonObject("models") : new JsonObject();
        FoliosBook.Models fallback = FoliosBook.Models.DEFAULT;
        ResourceLocation item = json.has("item") ? ResourceLocation.parse(json.get("item").getAsString()) : fallback.item();
        ResourceLocation open = json.has("open") ? ResourceLocation.parse(json.get("open").getAsString()) : fallback.open();
        ResourceLocation cover = fallback.cover();
        if (coverGroup.has("model")) {
            String named = coverGroup.get("model").getAsString();
            cover = named.equals("none") ? null : ResourceLocation.parse(named);
        }
        boolean guiModel = json.has("gui") ? json.get("gui").getAsString().equals("model") : fallback.guiModel();
        return new FoliosBook.Models(item, open, cover, !json.has("hands") || json.get("hands").getAsBoolean(), guiModel);
    }

    private static FoliosReveal.Use reveal(JsonElement json) {
        String effect;
        float seconds = FoliosReveals.DEFAULT_SECONDS;
        boolean once = false;
        boolean unread = false;
        if (json.isJsonObject()) {
            JsonObject object = json.getAsJsonObject();
            effect = string(object, "effect", FoliosReveals.DEFAULT.effect().toString());
            if (object.has("seconds")) seconds = Mth.clamp(object.get("seconds").getAsFloat(), 0.0F, 5.0F);
            once = object.has("once") && object.get("once").getAsBoolean();
            unread = object.has("unread") && object.get("unread").getAsBoolean();
        } else {
            effect = json.getAsString();
        }
        if (effect.equals("none")) return FoliosReveal.Use.NONE;
        ResourceLocation id = effect.contains(":") ? ResourceLocation.parse(effect) : ResourceLocation.fromNamespaceAndPath("folios", effect);
        if (FoliosReveals.get(id) == null) {
            Folios.LOGGER.warn("A guide asks for the reveal effect {}, which no mod has registered", id);
            return FoliosReveal.Use.NONE;
        }
        return new FoliosReveal.Use(id, seconds, once, unread);
    }

    private static FoliosIcon ownItem(ResourceLocation book) {
        JsonObject stack = new JsonObject();
        stack.addProperty("id", "folios:guide_book");
        JsonObject components = new JsonObject();
        components.addProperty("folios:guide_book", book.toString());
        stack.add("components", components);
        return FoliosIcon.read(stack);
    }

    private static FoliosBook.Textures textures(JsonObject json) {
        FoliosBook.Textures fallback = FoliosBook.Textures.DEFAULT;
        return new FoliosBook.Textures(texture(json, "page", fallback.page()), texture(json, "frame", fallback.frame()),
                texture(json, "boards", fallback.cover()), texture(json, "tab", fallback.tab()), texture(json, "tab_plate", fallback.tabPlate()),
                json.has("backdrop") ? ResourceLocation.parse(json.get("backdrop").getAsString()) : fallback.backdrop(), texture(json, "spotlight", fallback.spotlight()));
    }

    private static FoliosBook.Layout layout(JsonObject json) {
        FoliosBook.Layout fallback = FoliosBook.Layout.DEFAULT;
        JsonObject tabs = json.has("tabs") ? json.getAsJsonObject("tabs") : new JsonObject();
        JsonObject buttons = json.has("turn_buttons") ? json.getAsJsonObject("turn_buttons") : new JsonObject();
        JsonObject numbers = json.has("page_numbers") ? json.getAsJsonObject("page_numbers") : new JsonObject();
        JsonObject close = json.has("close_button") ? json.getAsJsonObject("close_button") : new JsonObject();
        return new FoliosBook.Layout(position(tabs, "x", fallback.tabX(), -20, 40), position(tabs, "y", fallback.tabY(), -20, 160),
                position(tabs, "spacing", fallback.tabSpacing(), -10, 30), position(buttons, "x", fallback.buttonX(), 0, 60),
                position(buttons, "y", fallback.buttonY(), 0, 170), position(numbers, "x", fallback.numberX(), -60, 60),
                position(numbers, "y", fallback.numberY(), 0, 170), position(close, "x", fallback.closeX(), 0, 125),
                position(close, "y", fallback.closeY(), 0, 169));
    }

    private static int position(JsonObject json, String key, int fallback, int min, int max) {
        return json.has(key) ? Mth.clamp(json.get(key).getAsInt(), min, max) : fallback;
    }

    private static ResourceLocation texture(JsonObject json, String key, ResourceLocation fallback) {
        return json.has(key) ? ResourceLocation.parse(json.get(key).getAsString()) : fallback;
    }

    private static String text(JsonObject json, String key, String fallback) {
        return json.has(key) && !json.get(key).isJsonNull() ? FoliosText.read(json.get(key)) : fallback;
    }

    private static String text(JsonObject json, String key, String translation, String fallback) {
        return json.has(key) && !json.get(key).isJsonNull() ? FoliosText.read(json.get(key)) : FoliosText.translation(translation, List.of(), fallback);
    }

    private static String string(JsonObject json, String key, String fallback) {
        return json.has(key) && !json.get(key).isJsonNull() ? json.get(key).getAsString() : fallback;
    }

    private static int integer(JsonObject json, String key, int fallback) {
        return json.has(key) ? json.get(key).getAsInt() : fallback;
    }

    private static @Nullable Integer argb(JsonObject json, String key) {
        if (!json.has(key) || json.get(key).isJsonNull()) return null;
        JsonElement value = json.get(key);
        String text = value.isJsonPrimitive() && value.getAsJsonPrimitive().isString() ? value.getAsString().strip() : "";
        if (text.startsWith("#") && (text.length() == 7 || text.length() == 9)) {
            try {
                int read = (int) Long.parseLong(text.substring(1), 16);
                return text.length() == 7 ? 0xFF000000 | read : read;
            } catch (NumberFormatException ignored) {
            }
        }
        Folios.LOGGER.error("\"{}\": {} isn't a colour; colours are written \"#RRGGBB\" or \"#AARRGGBB\"", key, value);
        return null;
    }

    private static int color(JsonObject json, String key, int fallback) {
        Integer value = argb(json, key);
        return value != null ? value & 0xFFFFFF : fallback;
    }
}
