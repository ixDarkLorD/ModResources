package net.ixdarklord.folios.internal.mixin.client;

import net.ixdarklord.folios.internal.client.FoliosLibrary;
import net.minecraft.client.renderer.ShaderManager;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.server.packs.resources.ResourceManager;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@Mixin(ShaderManager.class)
public abstract class ShaderManagerMixin {
    @Unique
    private @Nullable ResourceManager folios$manager;

    @Inject(method = "reload", at = @At("HEAD"))
    private void folios$keepManager(PreparableReloadListener.SharedState state, Executor tasks, PreparableReloadListener.PreparationBarrier barrier,
                                    Executor reloads, CallbackInfoReturnable<CompletableFuture<Void>> cir) {
        this.folios$manager = state.resourceManager();
    }

    @Inject(method = "apply", at = @At("TAIL"))
    private void folios$reloadBooks(CallbackInfo ci) {
        if (this.folios$manager != null) FoliosLibrary.reload(this.folios$manager);
    }
}
