package net.ixdarklord.folios.internal;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;

import java.util.Locale;
import java.util.function.BiConsumer;
import java.util.function.Function;

// What common code (the book item) asks of the client: set by the client's constructor. On a dedicated server
// nothing is set, and a book's name falls back to its translation key.
public final class GuideHooks {
    public static BiConsumer<ResourceLocation, InteractionHand> opener = (book, hand) -> {};
    public static Function<ResourceLocation, Component> names = GuideHooks::defaultName;
    public static Function<ResourceLocation, Component> authors = GuideHooks::defaultAuthor;

    private GuideHooks() {}

    public static void openFromItem(ResourceLocation book, InteractionHand hand) {
        opener.accept(book, hand);
    }

    public static Component bookName(ResourceLocation book) {
        return names.apply(book);
    }

    /** Who a book is from, for its item's tooltip. */
    public static Component bookAuthor(ResourceLocation book) {
        return authors.apply(book);
    }

    /** The display name of the mod whose namespace the book is in; the namespace in title case if no mod has it. */
    public static Component defaultAuthor(ResourceLocation book) {
        String namespace = book.getNamespace();
        return Component.literal(net.ixdarklord.coolcatcore.api.platform.Platform.getModName(namespace)
                .orElseGet(() -> namespace.substring(0, 1).toUpperCase(Locale.ROOT) + namespace.substring(1).replace('_', ' ')));
    }

    /** {@code guide.<namespace>.<path>.name}, with the path in title case as the fallback. */
    public static Component defaultName(ResourceLocation book) {
        String path = book.getPath();
        String last = path.substring(path.lastIndexOf('/') + 1).replace('_', ' ');
        StringBuilder title = new StringBuilder();
        for (String word : last.split(" ")) {
            if (word.isEmpty()) continue;
            if (!title.isEmpty()) title.append(' ');
            title.append(word.substring(0, 1).toUpperCase(Locale.ROOT)).append(word.substring(1));
        }
        return Component.translatableWithFallback("guide." + book.getNamespace() + "." + path.replace('/', '.') + ".name", title.toString());
    }
}
