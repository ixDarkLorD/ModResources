package net.ixdarklord.folios.internal.client;

import net.ixdarklord.folios.api.FoliosBooks;
import net.ixdarklord.folios.api.client.FoliosBook;
import net.ixdarklord.folios.api.client.FoliosEntry;
import net.ixdarklord.folios.internal.client.viewer.Viewers;
import net.ixdarklord.folios.internal.config.FoliosClientConfig;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

public final class BookLookup {
    private BookLookup() {}

    public static final KeyMapping KEY = new KeyMapping("key.folios.lookup", GLFW.GLFW_KEY_B, "key.categories.inventory");

    static final long HOLD_MILLIS = 650;
    private static final long HOVER_MILLIS = 150;

    public record Found(ResourceLocation book, FoliosBook.Location location, ItemStack bookItem) {
        boolean same(@Nullable Found other) {
            return other != null && book.equals(other.book) && location.equals(other.location);
        }
    }

    private static @Nullable Found shown;
    private static long shownAt;
    private static long heldSince = -1;
    private static @Nullable ClientTooltipComponent pending;
    private static boolean held;
    private static boolean fromViewer;

    public static @Nullable Found find(ItemStack stack) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || stack.isEmpty() || FoliosBooks.bookOf(stack) != null) return null;
        Inventory inventory = player.getInventory();
        Found found = book(inventory.getSelected(), stack);
        for (int slot = 0; found == null && slot < inventory.getContainerSize(); slot++) found = book(inventory.getItem(slot), stack);
        if (found != null || !FoliosClientConfig.LOOKUP_ANY_BOOK.get()) return found;
        for (FoliosBook book : FoliosLibrary.books().values()) {
            if (!FoliosLibrary.isListed(book.id()) || !FoliosLibrary.isLookedUpAnywhere(book.id())) continue;
            found = book(FoliosBooks.createStack(book.id()), stack);
            if (found != null) return found;
        }
        return null;
    }

    private static @Nullable Found book(ItemStack carried, ItemStack about) {
        ResourceLocation id = FoliosBooks.bookOf(carried);
        FoliosBook book = id != null ? FoliosLibrary.book(id) : null;
        if (book == null) return null;
        FoliosBook.Location location = book.about(about);
        if (location == null) return null;
        FoliosEntry entry = book.entry(location.entry());
        if (entry == null || !entry.isOpen()) return null;
        return new Found(id, location, carried.copyWithCount(1));
    }

    public static void hovering(ItemStack stack) {
        Found found = find(stack);
        if (found == null) {
            pending = null;
            return;
        }
        if (!found.same(shown)) heldSince = -1;
        shown = found;
        shownAt = FoliosClock.millis();
        pending = new LookupTooltip(found);
    }

    public static @Nullable ClientTooltipComponent takePending() {
        ClientTooltipComponent taken = pending;
        pending = null;
        if (taken == null && fromViewer && shown != null) return new LookupTooltip(shown);
        return taken;
    }

    public static void doneHovering() {
        pending = null;
    }

    static float progress(Found found) {
        if (heldSince < 0 || !found.same(shown)) return 0;
        return Math.min(1, (FoliosClock.millis() - heldSince) / (float) HOLD_MILLIS);
    }

    public static void tick(Minecraft minecraft) {
        long now = FoliosClock.millis();
        if (minecraft.screen != null && Viewers.any() && (shown == null || fromViewer || now - shownAt > HOVER_MILLIS)) {
            ItemStack viewed = Viewers.hovered();
            fromViewer = false;
            if (!viewed.isEmpty()) {
                hovering(viewed);
                fromViewer = shown != null && pending != null;
                pending = null;
            }
        }
        if (shown == null || now - shownAt > HOVER_MILLIS || minecraft.screen == null) {
            fromViewer = false;
            shown = null;
            heldSince = -1;
            return;
        }
        if (!held) {
            heldSince = -1;
            return;
        }
        if (heldSince < 0) heldSince = now;
        if (now - heldSince < HOLD_MILLIS) return;
        Found found = shown;
        shown = null;
        heldSince = -1;
        FoliosClient.open(found.book(), found.location());
    }

    public static void key(int key, int scancode, int action) {
        if (KEY.matches(key, scancode)) held = action != GLFW.GLFW_RELEASE;
    }

    public static void button(int button, int action) {
        if (KEY.matchesMouse(button)) held = action != GLFW.GLFW_RELEASE;
    }
}
