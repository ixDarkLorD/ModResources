# Changelog

## v3.2.0 Release | Nov 16, 2026
Recipes of every kind drawn in the book's own look, with a recipe layout API for mods' machines, JEI keys and bookmarks, the Compendium of every installed book, books on lecterns, moving pictures, quest rewards that run commands, a text size setting and read-aloud pages, and exporting a book as a website. Books written for 3.1 load unchanged: every new key is optional.

### ✨ New Features
- The `recipe` element draws any kind of recipe, including other mods' machines, with no recipe viewer needed: crafting, cooking, stonecutting and smithing as such, and any other as its ingredients, an arrow, the result and the block it is made at.
- Recipe layouts, for mod developers: `FoliosRecipeLayouts.register` lays out a mod's machine recipes the way a recipe viewer's category does. A layout places slots, progress arrows, burning flames, gauges, chances, text and textures, and can draw with Minecraft's GUI graphics and give tooltips of its own, all in the book's look. On 1.21 and 1.20.1 layouts are registered by recipe class.
- JEI: hovering an item in a recipe and pressing JEI's show-recipe key (**R**) or show-uses key (**U**) opens it in JEI, and a small button on each recipe's frame adds the recipe to JEI's bookmarks. New client settings `reading.bookmarkButton` and `reading.bookmarkCorner` hide the button or choose the corner it sits in.
- Holding the look-up key (**B**) over an item in JEI's, REI's or EMI's item list, bookmarks or recipe screen opens the item's page.
- Look-up now searches every installed book after the ones the player carries, so it works without the book at hand. A book can opt out with `"lookup": "carried"`, and the client setting `reading.lookupAnyBook` turns it off.
- The Compendium: crafted from a book and a bookshelf. Using it opens a list of every installed guide book, with a search box; choosing one turns it into that book, and sneaking and using that book turns it back into the Compendium. On a lectern it lets whoever uses it pick a book to read. A book can keep off its shelf with `"listed": false`.
- Guide books can be put on lecterns. Using the lectern opens the book for whoever uses it (reading there counts for quests); sneaking takes it back. The comparator signal and dropping the book when broken work as for a written book.
- Moving pictures: the `image` element plays a strip of frames (`"frames"`, `"frame_time"`), textures animated by their `.mcmeta`, and GIFs, in screen and hand-held books.
- Quest rewards can run `"commands"` and a data pack `"function"`, as the player who claims them, with a `"note"` to say what they give. New server settings under `rewards`: `commands`, `permissionLevel` (2), `maxCommands` (16) and `functions`.
- Text size: the client setting `reading.textScale` (1.0 to 2.0) draws pages larger, keeping the book about the same size.
- Read aloud: with the game's narrator on, a book reads its page as it opens and on every page turn. The client setting `reading.narratePages` turns it off.
- `/folios export <book>` writes the book as a website in `.minecraft/folios-export/` that reads like the book: its spreads as drawn in game, page-turn buttons with a turning leaf, arrow keys and swipes, category tabs, search, and working links. A text version of every entry sits beside it for search engines and screen readers.

### 🎨 Changes
- Recipe slots that take a tag show a `#` in their corner, and slots that take a list of items show a list mark; their tooltip shows every item they accept as icons (and the tag's name, on 26.1 and later).
- The block a recipe is made at is shown as a small badge on its frame's top-right corner, with room kept above the frame for it.
- Item slots on pages are drawn in Minecraft's inset style, in the book's colours; the result slot matches a recipe viewer's in size and sits centred beside the grid, with a larger arrow.
- The furnace arrow in cooking recipes fills up over the cooking time.
- The reward marker at the end of a quest's path is 2 pixels smaller.

### 🐛 Fixes
- A recipe that can't be drawn shows a message in the middle of its frame instead of breaking the page, and the error goes to the log.
- Recipe slot marks and chance labels are drawn over their items instead of behind them.
- A book with no categories no longer crashes when opened.

## v3.1.2 Release | Nov 2, 2026
Faster screen-style books on 1.20.1 and 1.21, which are now drawn once and reused, smaller tab icons, and a fix for the outline of locked pages.

### 🎨 Changes
- Decoration built from many small fills is drawn once into a texture and reused instead of being rebuilt every frame: the page edges, the title bar's ribbon and fold pocket, the tab tucks, and a hand-held book's torn edges, leaf edges and sketch lines.
- An open screen-style book is drawn into an off-screen image and reused within a game tick, instead of being redrawn every frame. It is redrawn on each tick, input or page change; page turns, 3D scenes, animated textures, enchantment glints and obfuscated text are drawn live. The result is pixel-identical to drawing the book directly. In testing, the front page went from about 383 to 440 FPS on 1.21 and from about 366 to 445 FPS on 1.20.1.
- A page heading's icon no longer shows an item tooltip or link when hovered.
- Unselected tab icons and page heading icons are drawn smaller. At GUI scale 3 and up they keep a whole number of screen pixels per texel (about 10 to 12 pixels); at GUI scale 1 and 2, where no such size exists, they are drawn as a 12-pixel image with evenly sized pixels.
- API: `FoliosPainter.quietItem` and `FoliosIcon.drawQuiet` draw an item or icon with no tooltip or link.
- API: `FoliosPainter.time(step)` returns the time held still between steps of `step` seconds, so something that only changes every few seconds (like an item cycling through a tag) lets the book reuse what it drew in between.

### 🐛 Fixes
- Items drawn larger or smaller than 16 pixels are drawn at the nearest size where every texel is a whole number of screen pixels, on a whole pixel, so enlarged and shrunk items no longer show uneven, smeared texels.
- Screen-style books draw much faster on 1.20.1 and 1.21: fills and text are batched, and back-to-back textures are sent in one draw instead of one draw each (an open book went from about 95 to over 300 FPS in testing).
- Hand-held books: the dark specks along the page edges are gone. They were gaps between edge strips stacked at different depths.
- The dashed outline around a locked page or element is drawn with its dashes 4 pixels apart again; 3.1.1 drew them 16 pixels apart.

## v3.1.1 Release | Oct 30, 2026
Fixes for locked elements and the performance of locked pages, and a clearer name for one lock key.

### 🎨 Changes
- The lock key `"show_unlock"` is now `"show_list"`. `"show_unlock"` is still read, so books written for 3.1.0 keep working. The Java field stays `FoliosLock.showUnlock`.
- The padlock on the seal keeps its light colour in dark mode.

### 🐛 Fixes
- An element locked by an `"obtained"` condition now opens once the item is obtained. Before, only category, entry and page locks were watched for obtained items.
- Locked pages and elements no longer lower the frame rate: their seal and frame were rebuilt from many small draw calls every frame. They now take a handful of draws, so a locked spread renders about as fast as a normal one.

## v3.1.0 Release | Oct 30, 2026
Locks on single pages and elements, index and search listings for pages and elements, an item look-up key, and a grid view for categories. Books written for 3.0 load unchanged: every new key is optional.

### ✨ New Features
- Page and element locks: `"requires"` (one objective or a list, all needed) and `"secret"` are now read on a page and on an element, as on entries and categories. A locked one is drawn as a locked panel in its place; its links, actions and tooltips are off until it opens.
- New lock keys:
  - `"show_unlock"` (default `true`): `false` leaves out the list of objectives and their progress.
  - `"peek"` (a float, default `1.0`): the opacity of the obscured preview of the page or element behind the panel, as a multiplier; `0.0` leaves it out, `0.5` makes it fainter, values above `1.0` make it plainer.
- `"index"` on a page or an element: `true`, or `{"name": ..., "icon": ...}`. It is listed in the book's index and search as its own entry, named after its title or the item it shows unless given a name, and opens the entry at that page or element. Links: `entry:<id>#@<page>` and `entry:<id>#@<page>.<element>` (both 0-based). Items it shows join the book's item index, so recipe and item links reach it.
- Item look-up: a key mapping, `key.folios.lookup` (default `B`, Inventory category). Hovering an item in a container screen while carrying a guide book that indexes it adds the book and "Hold B to learn more" to the tooltip; holding the key for 0.65 s opens the book at that page.
- `"categories"` in book.json: `"view"`: `"list"` (default) or `"grid"` (tiles, about 34 px wide, three across on a 136 px page; no progress bar for a category with fewer than two entries), and `"overflow"`: `"pages"` (default) or `"scroll"`.
- API:
  - `FoliosLock` gains `showUnlock` and `peek`; the 3-argument constructor is kept.
  - `FoliosEntry.listings()` and `FoliosEntry.Listing`.
  - `FoliosBook.Location` gains `element` (−1 for a whole page); the 2-argument constructor is kept.
  - `FoliosBook.categoryView()` and `FoliosBook.CategoryView`.
  - `FoliosLayout.mark(...)` and `takeMarks()` for named places within a page.
  - `FoliosPainter.silhouette(...)` and `clip(...)`, with default implementations.
  - `FoliosObjective.goal()`.

### 🎨 Changes
- Category tab paging: the buttons under the tabs move by a whole group (the number of tabs that fit), with a "page/pages" label and "Back"/"Next" tooltips. The mouse wheel over the tabs moves by a group too, and opening a category in another group jumps to it. The group size no longer depends on which tab is open.
- Scrollbars in scroll boxes, quests and the unlock list can be dragged; the thumb maps to the track's travel (track height minus thumb height).

### 🐛 Fixes
- Entities shown in previews get their own negative ids, so they no longer clash with entities in the world.
- A quest reward that doesn't fit in the inventory is dropped at the player's feet with no pickup delay and only that player able to take it, as `/give` does.

## v3.0.0 Release | Oct 25, 2026
A breaking release: book JSON gets one clear shape for everything, with `"format_version"` to say which, and older books are updated as they load. Pages can be set and paged in place, show live lists from mods and data packs, and lock on items obtained; the API's classes are all `Folios*`.

Books written for 2.x still load: Folios updates them in memory as it reads them and logs what changed. See the [migration guide](https://ixdarklord.github.io/Folios/docs/migrating-to-3.0/), or update a book's files at once with the [book upgrader](https://ixdarklord.github.io/Folios/upgrader/).

### 💥 Breaking Changes
- The API's classes are renamed from `Guide*` to `Folios*`: `FoliosBooks`, `FoliosBookItem`, `FoliosGuides` (was `Guides`), `FoliosBook`, `FoliosCategory`, `FoliosEntry`, `FoliosLock`, `FoliosObjective(s)`, `FoliosReveal(s)`, `FoliosStyles`, and under `page`: `FoliosIcon`, `FoliosLayout`, `FoliosPageElement` (was `GuidePage`), `FoliosPageElements` (was `GuidePageTypes`), `FoliosPainter`, `FoliosPalette`, `FoliosStack`, `FoliosText`. Folios's internal classes are renamed the same way.
- `book.json` has `"format_version": "3.0"`. A book without it is read as a 2.x book and upgraded as it loads, with a warning naming it; a 3.0 book still holding a 2.x shape logs which, and where.
- A page's `"anchor"` (a place links can go to) is now `"marker"`; `"anchor"` now sets a page down its top, middle or foot.
- The cover's settings are one group, `"cover"`: `color`, `texture`, `model` and `text` (was `"cover"` as a colour, `"cover_text"`, and `textures.cover`, now `textures.boards`).
- A handheld book's `tilt`, `distance` and `page_turn` move into `"handheld"`, beside `look_around` and `walk`.
- `"progress"` is `"progress_scope"`: `"player"` or `"copy"` (was `"book"`).
- `"item_model"` is gone (`"models"` › `"item"`), and so is `"colors"` › `"tooltip"` (`"panel"`).
- Colours are written only as `"#RRGGBB"` or `"#AARRGGBB"`.
- An entry's category is the folder it is in: its `"category"` key is gone, and so is the `"text"` shortcut for a one-page entry (write `"pages"`).
- `recipe`, `image`, `structure` and `build` take one id or a list under the one key (`"recipes"`, `"images"`, `"structures"` and `"builds"` are gone). A structure or build choice, and a map's node, has a `"label"` (was `"name"`). A spread's `"build"` names a build file; blocks written into it go under `"multiblock"`.
- Objectives: `category` is `read_category`, `book` is `read_book`, `item` is `carried`, and `count` is `goal`.
- Locks are `"requires"`: one objective or a list of them, all needed (was `"advancement"` and `"flag"` on the locked thing). `"secret"` stays.
- The gem at the middle of a book's cover can hold an icon, on the book item and on a handheld book: `"cover": {"icon": ...}`, an item or a texture path, sized with `"icon_size"`. Without it (or with `"none"`), the plain gem. A cover model marks its gem with `#icon` in the element's name.
- A long book name on the cover is set on two lines, as even as the words allow, when that makes it larger than one line shrunk to fit.
- A guide book's tooltip says who it is by from `"credits"` in book.json: `"authors"` (one or a list, joined "A, B and C") and `"prefix"`, the words before them ("Written by" by default; was "By: …" with `"author"`, and before that "From …" and the mod's name). `"author"` is upgraded to `credits` › `authors`. With no authors, it says nothing.

### ✨ New Features
- A book's `name`, `subtitle`, `summary`, `landing` and `credits` can be left out of book.json: they come from `folios.<namespace>.<book>.<key>` in the lang files (`.credits.authors` and `.credits.prefix` for the credits). Category names and descriptions come from `folios.<namespace>.<book>.category.<id>.name` / `.description`, and entry names from `folios.<namespace>.<book>.entry.<category>.<id>.name`.
- Every text can be Markdown, a translation key, or `{"translate": "key", "with": [...], "fallback": "..."}`. Markup has tags for `{lang:key|first|second}` (a translation), `{player}` (the reader's name), `{item:minecraft:diamond}` (the item in a small slot and its name, linking to its page in the book; `{item:minecraft:diamond|16}` sizes the slot, 8 to 18 pixels, 14 by default; a name too long for its line runs on beside its slot), `{slot:minecraft:diamond}` (the slot alone, for rows and grids of items, live lists' too, a grid's slots spread evenly across the page), `{entry:tools/scribe}` (a link with the entry's name) and `{flag:mymod:hard_mode|on|off}`.
- Overflow: an element or page whose text doesn't fit can `"flow"` on to the next page (as before), `"keep"` to its box, `"flip"` through its text in place (a framed box with a pager of up to 7 squares, its marker sliding to the page shown, clasps to step back and on with "Page: N/M" tooltips, and the mouse wheel), `"scroll"` its text in a framed box a line at a time (the mouse wheel, or a scrollbar to drag, fading into its frame at an edge with more beyond), or `"auto"` (flip when it would run on). `"height"` (`"fill"`, `"fit"`, pixels, or a share of the page such as `"60%"`) and `"min_height"` (pixels or a share) size the box.
- Alignment: `"alignment"` (`left`, `center`, `right`, `justify`) for text, `"title_alignment"` for titles, `"anchor"` (`top`, `center`, `bottom`) to set a page down its height, and `->text<-` / `->text` in Markdown to centre or right-align one paragraph. A title too long for its line shrinks a little, then ends with an ellipsis. Set them in book.json for every page, on a page, or on an element.
- Live lists (observable elements): a page or element can `"observe"` a source and write a line of markup for each of its rows (`"row": "- **{$name}**: {$cost}"`), with `sort` (`"-field"` the other way; numbers sort as numbers), `where` (`is`, `not`, `above`, `below`), `limit`, `header`, `footer`, `separator` and `empty`. The page is written again whenever the list changes. Mods give sources with `FoliosSources`: on the client (`register`) or on the server (`registerServer`, sent to each player as they join and after every data pack reload); data packs add rows to any source in `data/<namespace>/folios/sources/*.json`.
- Live lists from the game itself, with no code: `folios:items`, `folios:blocks` and `folios:entities` list a registry, narrowed by the page's `"of"` (a tag, `"#minecraft:logs"`, or a mod), and `folios:advancements` lists the advancements the reader has been shown, with whether each is `done`. Data packs can also take rows out of any source (`{"id": ..., "remove": true}`) and leave out rows or whole files unless mods are loaded (`"requires_mods"`). An open book now lays itself out again, at the same place, when what its live lists show changes.
- Popups: a link to an entity, a structure, a build or a multiblock (`[Blaze](entity:minecraft:blaze)`, `structure:`, `build:`, `multiblock:<entry>#<marker>`, or the tag `{entity:minecraft:blaze}`) shows it in a window over the book while the pointer is over its words, its name along the top and the scene turning under it; pressing the link pins the window, to turn and zoom. Mods add kinds of link of their own, with tooltips, popups and what pressing does: `FoliosLinks` and `FoliosPopup`.
- Mentioning a page in chat: point at a page with a book open and press M; the chat opens with a mention of it. Players with the book see the page's name, pressed to open it there; players without the book, or who haven't unlocked the page, see it scrambled.
- The `obtained` lock and objective: items the player has ever had in their inventory, kept with their progress, so a page can open on finding something even after it is used up. `carried` counts what they hold now.
- Quests: `"in_order": true` opens each objective once the one before it is done (the rest wait, muted and without a bar); an objective can be `"hidden"` (shown as "???" until done); `any` is done when one of its objectives is; `quest` is done when another quest is. Objectives can also be `read_category` and `read_book`.
- `"format_version"` and the book upgrader: Folios updates 2.x books as it reads them, from the same list of changes the [web upgrader](https://ixdarklord.github.io/Folios/upgrader/) uses to rewrite a book's files.

### 🎨 Changes
- Bars are redrawn with more to them: a rounded rim with fine ticks for its steps in place of the old segment lines, a shaded fill and a soft shadow; an objective's bar is a slim rounded groove.
- Category rows are taller, their icon centred on the frame, the unread mark level with the name, and more room between the name and its bar. A quest's objectives sit 4 pixels further apart.
- Bars, clasps, panels, item slots, the recipe arrow, the flip pager and scrollbars are drawn from GUI sprites in `folios:textures/gui/sprites/book/`, one per part with its shading painted in and its scaling in a `.png.mcmeta` (nine-slice, stretch or tile), tinted with the book's colours as before, so resource packs can restyle them.
- A spotlight's card is a texture, and a book can give its own: `"textures": {"spotlight": "mymod:textures/book/my_card.png"}`. A bar's ticks have a faint line in the groove between their marks.
- A quest objective's label too wide for its line is drawn smaller, then over two lines; one still too long is cut short with "…" and shown whole in a tooltip when hovered. A quest too tall for a page keeps its labels to one line each.
- Items drawn larger or smaller than 16 pixels (a spotlight's, items' slots in text) are drawn sharp at their size on 26.1 and later, not stretched from a 16-pixel picture.
- Entity previews: an entity's head no longer jitters, the camera starts further back and looks down from the corner, isometric, and turning scenes turn smoothly, drawn every frame.
- What moves in a book (its scenes turning, preview entities, pages turning and revealing, a held book opening) stands still while the game is paused, and goes on from there.
- Server quests: a data pack's `data/<namespace>/folios/quests/<name>.json` gives a quest the server follows and checks itself (`advancement`, `read`, `quest`, `flag`, `carried`, `obtained`, `source`, `any`), with `rewards`: items, and random gifts drawn from a weighted list (`random`, `random_rolls`). A quest page shows one with `"quest": "mymod:first_quest"`, and pressing its reward once it is done claims it: the server gives it once, into the inventory or at the player's feet. A resource pack can only change how the book shows it.
- Server quests can wait on others: `"requires"` keeps one shut, its objectives not counting, until what it names is done; its page says "Not yet open", or its own `"locked"` text. Books' locks can name server quests too (`{"quest": "mymod:first_quest"}`).
- Reading counts for server quests only as the server sees it: in a book the player has with them (or one the server opened), with each entry open a while (`readSeconds`), and no faster than `readsPerMinute`. A `strict` setting keeps rewarded quests from asking for reading at all. Operators have `/folios quest list|status|complete|reset|flag`, and mods `FoliosQuests` (completion listeners, server values and flags, finishing and resetting quests).
- Quest pages are a path: each objective a stop in a frame of its own, the line drawn in as far as the player has come, leading to the reward; done stops are ticked, the next one ringed. "2 of 5 done" heads it. A quest too tall for a page draws its labels smaller, then scrolls its objectives while its head and reward stay put. Quests take up to 32 objectives, and labels run to three lines. A server quest's reward is a grid of slots with counts, and a wrapped gift with a question mark for its random draws.
- The book upgrader can move books' quests to server quests: their objectives go to quest files in the data pack, and the pages name them.

### 🐛 Fixes
- A bar's shadow no longer has a sharp missing pixel at its bottom-right corner.
- Turning a page at some GUI scales no longer leaves thin lines across the leaf.
- Entities in scenes (entity pages and popups) move as they do in the world: a blaze's rods turn, wings beat.
- A heading in a page's text has a whole rule under it, as a page title has, and room under it.
- An element's title is no longer left at the foot of a page when what it heads moves on to the next: they move together.

## v2.1.1 Release | Oct 23, 2026
A mod's own guide book item shows its cover.

### 🐛 Fixes
- A mod's own guide book item (a `GuideBookItem` made for one book) shows its book's cover text and colours on every stack, not only on stacks given with the book in their `folios:guide_book` component: from the creative tab, `/give` or a recipe, it no longer has blank plates and Folios's own colours. `GuideBooks.bookOf` now gives such an item's own book when the stack names none.

## v2.1 Release | Oct 23, 2026
Books make better use of the screen at small GUI scales, and what is on their pages keeps clear of the page frame.

### ✨ New Features
- At a GUI scale smaller than Auto, a book keeps its size on the screen and its pages grow, so more fits on each: what is on them is drawn a step larger than the rest of the GUI (in whole pixels, so the print stays sharp), and the pages take the rest, as much as 2.5 times the default page. GUI scale 1 fits more than 2. A handheld book's pages grow too, as far as keeps its print easy to read. Pages of every kind lay themselves out to the page's size: text, recipes, scenes (which keep their shape), pictures, links and quests.

### 🐛 Fixes
- A screen book no longer shrinks at GUI scale 1 and 2: it is drawn as large as at Auto, and so are its tooltips.
- What is on a page keeps 4 pixels clear of the page frame on every side, and the turn buttons and page numbers sit clear of its corners (`turn_buttons` now defaults to `10`, `21`, `page_numbers` to `0`, `19`).
- The page frame keeps its corners and ornaments their size on a larger page.
- A book's subtitle on its front page shows whole: made a little smaller when it doesn't fit, rather than cut short.

## v2.0 Release | Oct 22, 2026
Pages hold elements, structures and builds join multiblocks, and a book chooses how it celebrates and what colours its panels take.

### ✨ New Features
- Multiblock mappings (and builds, and build spreads) can name a tag in place of a block, `"#minecraft:logs"`, with properties set on each block that has them (`"#minecraft:logs[axis=y]"`): any block of it will do, the window and the blocks-needed list show its blocks in turn, and the build guide in the world takes any of them.
- `structure` pages: structures from data packs (`data/<namespace>/structure/<path>.nbt`), asked of the server the first time they're shown. `"structure"` names one, `"structures"` several (ids, or `{"id": ..., "name": ...}`).
- `build` pages: builds designed in the book's own `builds/<name>.json` files, from a `pattern` and `mapping` as a multiblock's and/or `blocks`: single blocks (`"pos"`) and boxes (`"from"`/`"to"`, `"hollow"`), in order, air clearing. `"build"` names one, `"builds"` several.
- A guide book's tooltip says who it is from, under its name: the mod its namespace belongs to, or the book's own `"author"` in book.json (raw text or a translation key).
- A structure or build page with several to show picks between them under its window: clasps stepping back and on with the name between them (`"selector": "arrows"`, the default), or a numbered clasp each (`"numbers"`). They are for showing, not building: no blocks-needed list, nor an eye clasp to build them in the world.
- A multiblock's blocks needed no longer take room under its window: a clasp in the window's bottom-left corner lays a requirement list over the window: "Requirement list:" over the blocks in rows from the left, scrolled with the mouse wheel when there are more than fit, with a clasp to close it.
- Pages hold elements: a page is a `title` and its `"elements"` (text, recipes, multiblocks, structures, builds, entities, pictures, spotlights, links, quests), in any order, one under another. Each is written as its type is (`{"type": "recipe", "recipe": ...}`; a plain string is text), with its own title and text if it has them; one that doesn't fit starts the next page, and text runs on. A page written the old way, as one type, is a page of that one element, so existing books read as before. A mod's own element type works in a page's elements when it lays itself out through `GuideLayout.flow`.
- A handheld book's bar has the light/dark button too, and its pages go dark in dark mode (a book's `"colors"` › `"dark"` applies to them as to a screen book's).
- Bars with more to them: a category's completion bar is notched between its entries (a quest's between its objectives) with a rounded rim, a sunken groove and a light that sweeps across it once full; the front page shows "Mastery" with its trophy and "Progression:" with a percentage under it, over a gilt bar in the build guide's look; the build guide's bar has a rounded rim, a shadow, a shaded fill and marks at each tenth; and the requirement list's scroll bar has arrows lit while there is more that way and a raised thumb with grip lines.
- An entry's first page has the entry's icon before its title, over a mark of the book's colour heading the line under it; any page can name its own with `"icon"` (or `"none"` on the first page for none). A title without an icon has a plain line under it.
- The page's content stops 2 pixels short of the turn buttons, so nothing sits against them.
- Celebrations are a book's choice, and off unless it says so: `"celebrations"` in book.json, `true` for all of them, or an object turning parts (`"toast"`, `"sound"`, `"particles"`, `"fireworks"`) and events (`"objective"`, `"entry"`, `"category"`, `"quest"`, `"mastery"`, each `false`, `true` or an object of its own parts) off. Each objective of a quest done and each entry read can now be celebrated too, beside a category read through, a quest done and the book mastered; fireworks are for mastery alone.
- Toasts in the book's own look for what is celebrated: its panel ground and frame, the quest's, entry's or category's icon in a slot, a small heading over the name, and a line along its foot running down while it shows; mastery's shows the trophy.
- The panel colour scheme: `"panel"` in book.json (`background`, `frame`, `title`, `detail`) colours what a book shows off its pages: its tooltips, its toasts and the build guide's panel. `"colors"` › `"tooltip"`, as it was, is still read.
- The mastery heading on the front page: the trophy and "Mastery" over "Progression:" and a percentage, over a gilt bar split into quarters. Once the book is mastered the trophy glints with a rainbow running across it diagonally, a sheen sweeping over it now and then.

### 🐛 Fixes
- A long trail on a book's bar ("Why Can't I Sleep? › Sleep Quality") no longer gets cut short: it shrinks on its line a little, then goes onto two smaller lines, the book or category over the rest, and is cut only if it still doesn't fit.
- Blocks needed are counted by the items they take: a door's top half and a bed's head no longer count as another door or bed (nor a tall flower's top), and a double slab counts as two slabs. The same in the build guide's panel.

## v1.0 Release | Oct 22, 2026
Folios's guide books were first made inside CoolCatLib; this is them as a mod of their own, built on CoolCatLib.

On Minecraft 1.21 - 1.21.1, for Fabric, NeoForge and Forge, everything is as on later versions, with these differences:
- A book's own item models (`"models"`: `"item"`, `"open"`) are block-format models: `"mymod:handbook"` is `assets/mymod/models/item/handbook.json` (later versions read item model definitions under `items/`).
- Recipe pages read the recipes the client was sent as the player joined, rather than asking the server.
- Model elements in books' models may be turned by any angle, as on later versions.

### ✨ New Features
- Guide books (`net.ixdarklord.folios`: `api.GuideBooks`, `api.client.Guides`): in-game manuals written as JSON in a resource pack, so packs can add, translate and replace them, and `F3 + T` reloads them while you write.
- A book is a folder, `assets/<namespace>/folios/<book>/`: `book.json` (name, subtitle, the first page's text, style, colours, icon: an item or a texture, the book's own item if it names none), `categories/*.json` and `entries/**/*.json`. Every text can be a translation key.
- Two styles, any page showing in either: `screen`, a flat book in the middle of the screen with the world dimmed around it, a bar like its cover for where you are, a bookmark star, search (a glass that opens into a field while you type), light or dark paper and folding it away, swallowtail ribbon tabs coming out of the leaves' fore-edge, each a little deeper than the one above it and the open one risen to the top, for the front and its categories, with the bookmarks and an index of every entry A to Z at the foot (springing out under the pointer and knocked in when pressed), and leaves that fold across the spine; and `handheld`, the book held open in your hands in the world, raised from below and opened, its leaves turning with a shadow under them, its pages pressed with the pointer; the book sets how far it leans back (`"tilt"`, degrees, 6 by default), how far it is held from the eyes (`"distance"`, blocks, 0.64) and how its leaves turn (`"page_turn"`: `"bend"`, the default, curls each leaf as it goes, its writing following the curve; `"flat"` swings it stiffly). The reader's hands hold it, following its lean and distance (`"models"`/`"hands"`), and once it lies fully open the same bar grows out over its head, in the world with it, so a turning leaf passes in front of it; its close button shuts the book. No crosshair or block outline shows over it. Picked up, it is raised shut and opened with a click on its cover (or → / Enter / Space); the bar's close button shuts it again in the reader's hands, and Esc puts it away (and a click off the book does too: on by default for a handheld book, off for a screen one, set either way with `"close_on_click_outside"`).
- Both styles are drawn from texture layers, grey or white and tinted by the book's colours: `page`, `frame`, `cover`, `tab` (a stitched swallowtail ribbon), `tab_plate` (the rounded plate each tab's icon sits on) and, for screen books, an optional `backdrop`. Folios's own are at `folios:textures/book/`, so a resource pack can restyle every book, and a book can name its own under `"textures"`. A category can give its tab its own `"color"`. Page numbers and turn arrows are printed on their pages, so they turn with them. Where the tabs, turn buttons and page numbers sit is the book's `"layout"` (`tabs`, `turn_buttons`, `page_numbers` and `close_button`, for a page close clasp where one is drawn, each with `x` and `y`; tabs also `spacing`). Back, previous, next and close are small eight-sided clasps with pixel icons that lift under the pointer. `GuideStyles.register` adds more.
- Text is a small Markdown: headings, bullet and numbered lists, notes, rules, bold, italic, underline, strikethrough, code, colours, key names, and links to entries, anchors, categories and web pages. Long text runs on over as many pages as it needs by itself.
- Pages: text, spotlight (an item shown large; pressing that item anywhere in the book comes back to it), image (several shown in turn), recipe (crafting, smelting, stonecutting and smithing, the block each is made at hung under it on a tag, asked of the server as clients aren't sent recipes), spread (one thing over both pages of the open book, across the fold: a wide picture, a build to drag round with its eye clasp, or a map of places linked to entries and joined by dotted paths; it starts on a left page and is laid out as one page over both: one frame joined across the fold, its title and text centred, one page number at the fold, and its window framed like a print laid on the page, running unbroken over the spine; `GuidePage.spread()` lets a mod's page do the same), entity and multiblock (turning scenes on a ground of grid lines, entities with their shadow; drag one to turn it yourself, and a clasp puts it back; what a build takes is listed). A build's eye clasp shows it in the world to be built: ghost blocks stand where you look, turned the way you face, until a right-click sets them down; the layer to build now is clearest, wrong blocks show red, and a panel on the HUD tracks the build's progress and what is still needed, until it is done (a toast says so), you walk away, or sneak + right-click puts it away, links and empty. `GuidePageTypes.register` adds a mod's own; pages draw through a `GuidePainter`, so one page works on both styles.
- Reveal effects: a page's content shows once its leaf is down, by an effect that tells everything drawn on it how faded and how far moved it is by where it is on the page, so every page type, a mod's own too, takes part. `folios:rise` (the default), `fade`, `ink`, `sweep`, `scatter`, `burn` (each thing is burnt in turn down the page and along each line, flaring white-hot, flames licking up off it, charring and settling, with sparks and smoke) and `runes` (parts show as glowing runes that flicker and settle into their words, under drifting runes and a shimmer of light) come with it, and `GuideReveals.register` adds a mod's own (`GuideReveal`: a look per thing drawn, its fade, move, tint and how much of its text shows as runes, an overlay drawn over the page while it plays, and `around`, drawn about each letter, item or picture as it is revealed). Items and scenes take part too, fading, tinting and moving with the effect in both styles (`GuidePainter.item` and `scene` take a colour for a page's own drawing). A spread's pages reveal together, across the fold; other pages one after the other. A book chooses one in book.json and an entry may choose its own: `"reveal": "folios:ink"`, or `{"effect": ..., "seconds": 0.6, "once": true}` to play only the first time each spread is seen this game (pages of entries read in an earlier game count as seen), `"unread": true` to play only on spreads the reader has never been shown in full (kept with their reading progress, so not again after a restart or on another computer), or `"none"`.
- What a reveal effect draws over a page (sparks, smoke, light, runes, and what it draws about each thing) fades out towards the page's edges and its fold, melting into the paper rather than stopping at its border; addon effects get this too.
- Scenes on pages (entities, builds) are drawn sharp at four texture pixels to a page pixel, zoom with the mouse wheel and turn by dragging, and a clasp puts them back. A build lists the blocks it needs under it, most needed first in framed slots, with a heading and clasps to page through long lists; build spreads list them across the fold.
- The front page shows a mastery bar, how many of all the book's quest objectives are done, with a trophy; every bar in the book is drawn as pixel art.
- On a screen book a turning leaf bends as it goes (`"page_turn": "flat"` swings it stiffly), what is on it bending with it.
- Tooltips in the books take on the book's colours: a ground from its cover and a gilt frame warmed by its accent, a name, and a quieter line under it saying more. A book sets its whole colour scheme with `"colors"`: the page's colours by name (`paper`, `text`, `muted`, `heading`, `accent`, `link`, `panel`, `line`), the same under `"dark"` for a screen book in dark mode, and `"tooltip"` (`background`, `frame`, `title`, `detail`); any left out keep the style's own.
- Quests and progress: a `quest` page lists objectives with progress bars, followed live: advancements, entries or categories read, the whole book, flags, items carried, and values a mod reports (`GuideObjectives.register`). A quest's entry shows how far along it is on its row, categories show how much of them has been read as bars, and a toast says when a quest is done.
- Finishing part of a book is celebrated, once each: every entry of a category read brings a toast, a chime and sparkles round the player; mastery (every quest done) a toast, the challenge fanfare and fireworks in the book's colours.
- Categories, entries and pages can be locked behind advancements (the server says which the player has) or flags set in code (`Guides.setFlag`), and hidden until they open (`secret`). What has been read, the spreads shown, bookmarks and where you left off are kept on the server, so they follow the player to any computer: with each player by default, or, with `"progress": "book"` in book.json, on each copy of the book, which carries its own like a notebook (entries read in it still count for the player's quests). Unread entries are marked with a blinking sparkle and progress is shown.
- `folios:guide_book` is an item for any book (`GuideBooks.createStack(id)`, or `createStack(item, id)` for a mod's own `GuideBookItem`, or `/give @s folios:guide_book[folios:guide_book="mymod:handbook"]`), named after its book; `GuideBookItem` makes a mod's own. `GuideBooks.open(player, book, entry)` opens one from the server.
- Its look: a bound book in three dimensions in the hand, on the ground and in frames (leather in the book's cover colour, gilt corners, a strap and clasp, its name and subtitle printed on the cover), and a flat icon in inventory slots unless the book asks for its model there too (`"models"`/`"gui": "model"`). A book's `"models"` can name its own item model (`"item"`; `"item_model"` still works), its own open book (`"open"`) and what sits on a handheld book's boards (`"cover"`: a model in the block and item model format, laid on each board, its tinted faces taking the cover colour; `"none"` for nothing). Item models can use the `folios:guide_cover` tint (the book's cover colour) and the `folios:guide_cover_text` special model (its name and subtitle, placed with `x`, `title_y`, `subtitle_y`, `z` and `width`).
- Others see a handheld book being read: the reader holds it up open in both hands. It is the `folios:guide_reading` component on the book in hand, put on and taken off by the server; a mannequin given a book with it is shown reading.
- Reading together: players within 16 blocks of someone reading a book see it in the reader's hands, held part open by its bottom corners at chest height: a handheld book at the spread they have open, its leaves turning as they turn them, so they can read along; a screen book as a likeness of its pages. The reader faces their book.
- A handheld book put away lying open opens again by itself where it was left (an entry's page, the front, a category, the index or the bookmarks); put away shut, it is raised shut. Its pages' content reveals once the cover lies open, not while it swings.
- The bar over a book is a ribbon banner: a cloth band in the cover's colour with swallowtail ends folded behind it, stitched in gilt, its buttons on small brass plates.
- When a handheld book opens, a hint over its bar (Minecraft's right-click icon, framed as the book's tooltips are) says the right button held looks about; it fades after a few seconds and isn't shown again once you have looked about.
- While a handheld book is open the reader can look about, holding the right mouse button, and walk, jump, sneak and sprint with the movement keys (the arrow keys still turn the leaves); a book turns either off with `"handheld": {"look_around": false, "walk": false}`. Put away, it goes back into the hand just as the held item lies there.
- The perspective key works while a handheld book is open: from outside, you see yourself holding it open, and the mouse turns the view freely (as the book's `look_around` allows); back in first person, the pointer reads the pages again.
- A handheld book is held steady: it doesn't sway as the view turns or bob as the reader walks, and its cover swings open in one smooth sweep. The bar folds away from a pocket in the middle of its foot, an arrow in it, where its pull is once it is folded.
- Pages have a rough-cut head and foot, and the leaves at their sides are uneven, some a hair short.
- A screen book used from the hand is raised out of it and opened part way in 3D first, its halves leaning up from the spine and its pages a pixel-art likeness of pages (a heading, a rule, lines of scribbled writing); others see it held part open too (`folios:guide_book_half_open`), and its screen comes up once it lies open; closed, the book shuts and goes back into the hand.
- Held shut, a handheld book's tooltip over its cover's name plate shows the name and subtitle, and over its lower plate the summary (or subtitle), above "Click to open".
- A handheld book held shut is the book item: the item's leather on its boards, its title, emblem and subtitle laid out as on the item's cover. In the bar, the book's icon sits in a slot. A cover model's box can show hold the book shut (`#shut` in its name, as the strap and clasp do: as the book opens they unlatch first, swinging out about the board's fore-edge before the cover moves, and are carried off behind the boards, gone once it lies open) or only once it lies open (`#open`), or be wrapped round the spine, bending with it as the cover opens (`#spine`, as the bands across it are), and can sit on one board only (`"board": "front"` or `"back"`), and boxes turn in the board's own proportions, so a square stays square.
- A book model marks where its lettering goes: an element named with `#title` or `#subtitle` (a plate, or an invisible box) has the line centred on its face, sized to it; `folios:guide_cover_text` reads them with `"markers": "<model>"`.
- A new look for the default book: leather with a tooled frame, the name and subtitle large on gold-rimmed plates, engraved gold corner brackets with rivets, a gem in the book's accent colour set in a gold lozenge, an engraved clasp with a keyhole, ridged bands over the spine, cleaner page edges, and a matching flat icon tinted with the cover. Shown as a model in slots, it leaves out the lettering, too small to read there. The `folios:guide_cover` tint takes `"part": "accent"` for the book's own colour, and cover models tint faces with `"tintindex": 1` the same way. A book places its lettering with `"cover_text"`: `title` and `subtitle`, each `x`, `y`, `size` and `width`.
- A book can have a `"summary"`: then its name and its subtitle (smaller, under it) share the cover's upper plate and the summary, up to two lines set to fit, has the lower one. A cover model marks where it goes with `#summary`, and `"cover_text"` takes `summary` as it does `title` and `subtitle`.
- A build shown in the world is drawn as its own blocks, see-through (CoolCatLib's `GhostBlocks`), the layer to build now clearer; its panel on the HUD takes the book's tooltip look and colours, and is as wide as what it holds, longer lines shrinking or wrapping to fit. Which corner of the screen it sits in and how far in from it are client settings (`buildPanel`: `corner`, `x`, `y`).
- A template resource pack with a complete example book, every kind of page and a README of the keys, is in `templates/folios-book-template`.
