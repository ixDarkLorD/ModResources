package net.ixdarklord.folios.internal.client.paint;

import net.ixdarklord.coolcatcanvas.api.client.viewport.SceneViewport;
import net.ixdarklord.coolcatcanvas.internal.client.viewport.SceneViewportManager;
import net.ixdarklord.folios.api.client.page.FoliosPalette;
import net.ixdarklord.folios.internal.client.FoliosSession;
import net.ixdarklord.folios.internal.compat.GuiGraphicsExtractor;
import net.ixdarklord.folios.internal.compat.RenderPipelines;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;

import java.util.List;

public final class ScreenPainter extends AbstractPainter {
    private static final int UV = 1 << 14;
    private final GuiGraphicsExtractor graphics;

    public ScreenPainter(GuiGraphicsExtractor graphics, float x, float y, float scale, FoliosPalette palette, FoliosSession session, Navigator navigator,
                         float time, float pointerX, float pointerY, List<Hit> hits) {
        super(palette, session, navigator, time, pointerX, pointerY, hits);
        this.graphics = graphics;
        graphics.pose().pushMatrix();
        graphics.pose().translate(x, y);
        graphics.pose().scale(scale, scale);
    }

    public void end() {
        graphics.pose().popMatrix();
    }

    @Override
    public boolean flat() {
        return true;
    }

    @Override
    public void fill(int x0, int y0, int x1, int y1, int argb) {
        graphics.fill(x0, y0, x1, y1, argb);
    }

    @Override
    public void text(FormattedCharSequence text, int x, int y, int argb) {
        graphics.text(font, text, x, y, argb, false);
    }

    @Override
    public void texture(ResourceLocation texture, int x, int y, int width, int height, float u0, float v0, float u1, float v1, int argb) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, texture, x, y, u0 * UV, v0 * UV, width, height,
                Math.round((u1 - u0) * UV), Math.round((v1 - v0) * UV), UV, UV, argb);
    }

    @Override
    public void above(Runnable draw) {
        graphics.nextStratum();
        draw.run();
    }

    @Override
    protected void drawItem(ItemStack stack, int x, int y, int argb) {
        TintedGuiItems.draw(argb, () -> graphics.fakeItem(stack, x, y));
        if ((argb >>> 24) >= 160) graphics.itemDecorations(font, stack, x, y);
    }

    @Override
    public void scene(SceneViewport viewport, int x, int y, int width, int height) {
        viewport.use();
        int view = SceneViewportManager.textureId(viewport);
        if (view >= 0) graphics.texture(view, x, y, x + width, y + height, 0.0F, 1.0F, 1.0F, 0.0F, 0xFFFFFFFF);
    }

    @Override
    public void scene(SceneViewport viewport, int x, int y, int width, int height, float u0, float u1) {
        viewport.use();
        int view = SceneViewportManager.textureId(viewport);
        if (view >= 0) graphics.texture(view, x, y, x + width, y + height, u0, u1, 1.0F, 0.0F, 0xFFFFFFFF);
    }

    @Override
    public void scene(SceneViewport viewport, int x, int y, int width, int height, float u0, float v0, float u1, float v1, int argb) {
        viewport.use();
        int view = SceneViewportManager.textureId(viewport);
        if (view >= 0) graphics.texture(view, x, y, x + width, y + height, u0, u1, 1 - v0, 1 - v1, argb);
    }

    @Override
    protected void pushed() {
        graphics.pose().pushMatrix();
    }

    @Override
    protected void popped() {
        graphics.pose().popMatrix();
    }

    @Override
    public void clip(int x, int y, int width, int height, Runnable draw) {
        graphics.enableScissor(x, y, x + width, y + height);
        try {
            draw.run();
        } finally {
            graphics.disableScissor();
        }
    }

    @Override
    protected void translated(float x, float y) {
        graphics.pose().translate(x, y);
    }

    @Override
    protected void scaled(float factor) {
        graphics.pose().scale(factor, factor);
    }
}
