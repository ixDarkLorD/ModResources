package net.ixdarklord.folios.internal.client;

import net.ixdarklord.folios.api.client.GuideBook;
import net.ixdarklord.folios.api.client.GuideCategory;
import net.ixdarklord.folios.api.client.GuideEntry;
import net.ixdarklord.folios.api.client.page.GuideLayout;
import net.ixdarklord.folios.api.client.page.GuidePage;
import net.ixdarklord.folios.api.client.page.GuideText;
import net.ixdarklord.folios.internal.client.page.ErrorPage;
import net.ixdarklord.folios.internal.core.Folios;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

// A book as laid out for the reader's language and progress: each entry's pages are set out the first time they're
// shown and kept until something they depend on changes (a reload, the language, an unlock).
public final class GuideSession {
    /** An entry's pages, ready to draw: anchors and the pages of its JSON point into them. */
    public record EntryPages(List<GuidePage.Laid> pages, Map<String, Integer> anchors, int[] starts) {
        /** Where a page of the entry's JSON begins among the laid pages. */
        public int start(int page) {
            return page < 0 || page >= starts.length ? 0 : starts[page];
        }

        /** Which page of the entry's JSON a laid page came from. */
        public int source(int laid) {
            int source = 0;
            for (int index = 0; index < starts.length; index++) {
                if (starts[index] <= laid) source = index;
            }
            return source;
        }
    }

    /** Where a link goes. */
    public record Target(@Nullable String entry, int page, @Nullable String category, @Nullable String url) {}

    private final GuideBook book;
    private final GuideLayout layout;
    private final String language;
    private final int progress;
    private final Map<String, EntryPages> entries = new HashMap<>();
    private @Nullable Map<String, String> searchIndex;

    GuideSession(GuideBook book) {
        this.book = book;
        this.layout = new GuideLayout(book, Minecraft.getInstance().font);
        this.language = Minecraft.getInstance().getLanguageManager().getSelected();
        this.progress = GuideProgress.version();
    }

    public GuideBook book() {
        return book;
    }

    public GuideLayout layout() {
        return layout;
    }

    boolean isCurrent() {
        return language.equals(Minecraft.getInstance().getLanguageManager().getSelected()) && progress == GuideProgress.version();
    }

    void close() {
        layout.close();
    }

    public EntryPages entry(String id) {
        return entries.computeIfAbsent(id, this::lay);
    }

    private EntryPages lay(String id) {
        GuideEntry entry = book.entry(id);
        List<GuidePage.Laid> pages = new ArrayList<>();
        Map<String, Integer> anchors = new HashMap<>();
        if (entry == null) return new EntryPages(pages, anchors, new int[0]);
        int[] starts = new int[entry.pages().size()];
        for (int index = 0; index < entry.pages().size(); index++) {
            GuideEntry.Page page = entry.pages().get(index);
            // A page over both pages starts on a left one.
            if (page.lock().isOpen() && page.page().spread() && pages.size() % 2 == 1) pages.add(painter -> {});
            starts[index] = pages.size();
            if (!page.lock().isOpen()) continue;
            if (page.anchor() != null) anchors.put(page.anchor(), pages.size());
            try {
                // The entry's icon heads its first page; a later page shows one only if it names its own.
                layout.titleIcon(page.icon() != null ? page.icon() : index == 0 ? entry.icon() : net.ixdarklord.folios.api.client.page.GuideIcon.NONE);
                pages.addAll(page.page().lay(layout));
            } catch (RuntimeException e) {
                Folios.LOGGER.error("Couldn't lay out page {} of the entry {} of the guide {}", index + 1, id, book.id(), e);
                pages.addAll(new ErrorPage("This page couldn't be shown: " + e).lay(layout));
            }
        }
        layout.titleIcon(net.ixdarklord.folios.api.client.page.GuideIcon.NONE);
        if (pages.isEmpty()) pages.add(painter -> {});
        return new EntryPages(List.copyOf(pages), Map.copyOf(anchors), starts);
    }

    /** A laid page of an entry as a place in the book. */
    public GuideBook.Location location(String entry, int laid) {
        return new GuideBook.Location(entry, entry(entry).source(laid));
    }

    /** Which laid page of its entry a place is. */
    public int pageOf(GuideBook.Location location) {
        return entry(location.entry()).start(location.page());
    }

    // ---- Links ----

    public @Nullable Target resolve(String link) {
        if (link.startsWith("http://") || link.startsWith("https://")) return new Target(null, 0, null, link);
        if (link.startsWith("category:")) {
            String id = link.substring(9);
            GuideCategory category = book.category(id);
            return category != null && category.isOpen() ? new Target(null, 0, id, null) : null;
        }
        String entry = link.startsWith("entry:") ? link.substring(6) : link;
        String anchor = null;
        int hash = entry.indexOf('#');
        if (hash >= 0) {
            anchor = entry.substring(hash + 1);
            entry = entry.substring(0, hash);
        }
        GuideEntry found = book.entry(entry);
        if (found == null || !found.isOpen()) return null;
        int page = 0;
        if (anchor != null) {
            Integer at = entry(entry).anchors().get(anchor);
            if (at != null) page = at;
        }
        return new Target(entry, page, null, null);
    }

    /** What a link's tooltip says: where it goes. */
    public Component describe(String link) {
        Target target = this.resolve(link);
        if (target == null) return Component.translatableWithFallback("folios.link.locked", "Not yet discovered");
        if (target.url() != null) return Component.literal(target.url());
        if (target.category() != null) {
            GuideCategory category = book.category(target.category());
            return category != null ? category.title() : Component.literal(target.category());
        }
        GuideEntry entry = book.entry(target.entry());
        return entry != null ? entry.title() : Component.literal(String.valueOf(target.entry()));
    }

    // ---- Search ----

    /** The open entries whose name or words contain every word of a query, best matches (by name) first. */
    public List<GuideEntry> search(String query) {
        String[] words = query.toLowerCase(Locale.ROOT).strip().split("\\s+");
        if (searchIndex == null) {
            searchIndex = new HashMap<>();
            for (GuideEntry entry : book.entries().values()) {
                StringBuilder text = new StringBuilder();
                for (GuideEntry.Page page : entry.pages()) text.append(' ').append(GuideText.plain(page.page().searchText()));
                searchIndex.put(entry.id(), text.toString().toLowerCase(Locale.ROOT));
            }
        }
        List<GuideEntry> named = new ArrayList<>();
        List<GuideEntry> mentioned = new ArrayList<>();
        for (GuideEntry entry : book.entries().values()) {
            if (!entry.isOpen()) continue;
            GuideCategory category = book.category(entry.category());
            if (category == null || !category.isOpen()) continue;
            String name = entry.title().getString().toLowerCase(Locale.ROOT);
            String body = searchIndex.getOrDefault(entry.id(), "");
            boolean inName = true;
            boolean anywhere = true;
            for (String word : words) {
                if (word.isEmpty()) continue;
                inName &= name.contains(word);
                anywhere &= name.contains(word) || body.contains(word);
            }
            if (inName) named.add(entry);
            else if (anywhere) mentioned.add(entry);
        }
        named.addAll(mentioned);
        return named;
    }
}
