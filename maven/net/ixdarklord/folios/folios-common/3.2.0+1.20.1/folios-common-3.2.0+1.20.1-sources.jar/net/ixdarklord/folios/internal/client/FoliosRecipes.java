package net.ixdarklord.folios.internal.client;

import net.ixdarklord.folios.internal.compat.RecipeDisplay;
import net.ixdarklord.folios.internal.core.Folios;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class FoliosRecipes {
    private static final Map<ResourceLocation, List<RecipeDisplay>> KNOWN = new HashMap<>();

    private FoliosRecipes() {}

    public static synchronized @Nullable List<RecipeDisplay> get(ResourceLocation recipe) {
        List<RecipeDisplay> displays = KNOWN.get(recipe);
        if (displays != null) return displays;
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return null;
        try {
            displays = level.getRecipeManager().byKey(recipe)
                    .map(found -> RecipeDisplay.of(found, level.registryAccess()))
                    .map(List::of)
                    .orElse(List.of());
        } catch (RuntimeException failure) {
            Folios.LOGGER.warn("Couldn't read recipe {}", recipe, failure);
            displays = List.of();
        }
        KNOWN.put(recipe, displays);
        return displays;
    }

    public static synchronized void tick() {
    }

    public static synchronized void clear() {
        KNOWN.clear();
    }
}
